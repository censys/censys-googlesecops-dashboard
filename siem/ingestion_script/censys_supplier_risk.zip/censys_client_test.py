# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# pylint: disable=line-too-long
# pylint: disable=g-importing-member
# pylint: disable=invalid-name
# pylint: disable=g-multiple-import
# pylint: disable=unused-argument
# pylint: disable=g-import-not-at-top
# pylint: disable=g-bad-import-order
# pylint: disable=missing-class-docstring
# pylint: disable=missing-function-docstring
# pylint: disable=g-bad-exception-name

"""Unit tests for the censys_client module."""

import json
import sys
import time
import unittest
from unittest.mock import MagicMock, patch


# --- Bootstrap all external dependencies before any project imports ---


class MockConnectTimeout(Exception):
  pass


class MockReadTimeout(Exception):
  pass


mock_requests_exceptions = MagicMock()
mock_requests_exceptions.ConnectTimeout = MockConnectTimeout
mock_requests_exceptions.ReadTimeout = MockReadTimeout
mock_requests_mod = MagicMock()
mock_requests_mod.exceptions = mock_requests_exceptions

sys.modules["requests"] = mock_requests_mod
sys.modules["requests.exceptions"] = mock_requests_exceptions


class MockUtils:
  @classmethod
  def cloud_logging(cls, msg, severity="INFO"):
    pass

  @classmethod
  def get_env_var(cls, name, required=False, default=None, is_secret=False):
    return default

  @classmethod
  def get_value_from_secret_manager(cls, path):
    return "mock_secret"


class MockIngestV1:
  @classmethod
  def ingest(cls, data, log_type):
    pass


class MockEnvConstants:
  ENV_CHRONICLE_SERVICE_ACCOUNT = "CHRONICLE_SERVICE_ACCOUNT"
  ENV_CHRONICLE_PROJECT_NUMBER = "CHRONICLE_PROJECT_NUMBER"


mock_common = MagicMock()
mock_common.utils = MockUtils()
mock_common.ingest_v1 = MockIngestV1()
mock_common.env_constants = MockEnvConstants()

sys.modules["common"] = mock_common
sys.modules["common.utils"] = MockUtils()
sys.modules["common.ingest_v1"] = mock_common.ingest_v1
sys.modules["common.env_constants"] = mock_common.env_constants

sys.modules["google"] = MagicMock()
sys.modules["google.cloud"] = MagicMock()
sys.modules["google.cloud.storage"] = MagicMock()
sys.modules["google.cloud.exceptions"] = MagicMock()
sys.modules["google.cloud.resourcemanager_v3"] = MagicMock()

from exception_handler import CensysException, RunTimeExceeded  # noqa: E402
import constant  # noqa: E402
import censys_client  # noqa: E402

INGESTION_SCRIPTS_PATH = ""

# ---- Helper ----


def _make_response(status_code=200, json_data=None, headers=None, text=""):
  response = MagicMock()
  response.status_code = status_code
  response.headers = headers or {}
  response.text = text or (json.dumps(json_data) if json_data else "")
  if json_data is not None:
    response.json.return_value = json_data
  else:
    response.json.side_effect = ValueError("no JSON")
  return response


def _make_client(
    access_token="test-token",
    organization_id="org-uuid",
    supplier_names="",
    risk_names="",
    inserted_after_time="1970-01-01T00:00:00Z",
    bucket_name="my-bucket",
):
  return censys_client.CensysClient(
      access_token=access_token,
      organization_id=organization_id,
      supplier_names=supplier_names,
      risk_names=risk_names,
      inserted_after_time=inserted_after_time,
      bucket_name=bucket_name,
  )


def _make_event(event_id, inserted_at, change_type="opened"):
  """Build a minimal risk-event dict matching the live API shape.

  The live schema (per https://docs.censys.com/reference/v1-supply-chain-list-risk-events)
  carries `id`, `change_type`, `occurred_at`, `inserted_at`, and a nested
  `risk_instance` — there is no `end_of_events` field on the response, and
  pagination has no field-level concept of a "cursor" beyond page_token.

  Args:
    event_id: The event ID.
    inserted_at: RFC3339 timestamp used for both inserted_at and occurred_at.
    change_type: The event change type (opened, resolved or reopened).

  Returns:
    A risk-event dict.
  """
  return {
      "id": event_id,
      "change_type": change_type,
      "occurred_at": inserted_at,
      "inserted_at": inserted_at,
      "risk_instance": {"id": f"instance-{event_id}"},
  }


class TestBuildAuthHeaders(unittest.TestCase):
  """Tests for _build_auth_headers."""

  def test_returns_bearer_authorization_header(self):
    client = _make_client(access_token="my-pat")
    headers = client._build_auth_headers()
    self.assertEqual(headers["Authorization"], "Bearer my-pat")

  def test_includes_user_agent(self):
    client = _make_client()
    headers = client._build_auth_headers()
    self.assertIn("User-Agent", headers)

  @patch("censys_client.platform.python_version", return_value="3.12.1")
  @patch("censys_client.time.time", return_value=1735500000.0)
  def test_user_agent_matches_expected_format(self, mock_time, mock_py_version):
    client = _make_client()
    headers = client._build_auth_headers()
    self.assertEqual(
        headers["User-Agent"],
        f"CensysSRGoogleSecopsSIEM/{constant.INTEGRATION_VERSION} "
        f"(GoogleSecopsSIEM/{constant.INTEGRATION_VERSION}; "
        "Python/3.12.1; ts=1735500000)",
    )

  @patch("censys_client.time.time")
  def test_user_agent_ts_reflects_call_time(self, mock_time):
    client = _make_client()
    mock_time.return_value = 1000.0
    first = client._build_auth_headers()["User-Agent"]
    mock_time.return_value = 2000.0
    second = client._build_auth_headers()["User-Agent"]
    self.assertIn("ts=1000", first)
    self.assertIn("ts=2000", second)
    self.assertNotEqual(first, second)


class TestClientUsesFixedBaseUrl(unittest.TestCase):
  """base_url is hardcoded, not user-configurable."""

  def test_base_url_matches_constant(self):
    client = _make_client()
    self.assertEqual(client.base_url, constant.CENSYS_API_BASE_URL)


class TestParseRetryAfter(unittest.TestCase):
  """Tests for _parse_retry_after."""

  def test_parses_integer_retry_after(self):
    client = _make_client()
    response = MagicMock()
    response.headers = {"Retry-After": "30"}
    delay = client._parse_retry_after(response)
    self.assertEqual(delay, 30)

  def test_clamps_to_max(self):
    client = _make_client()
    response = MagicMock()
    response.headers = {"Retry-After": "9999"}
    delay = client._parse_retry_after(response)
    self.assertEqual(delay, constant.MAX_RETRY_AFTER_SECONDS)

  def test_falls_back_to_default_on_missing_header(self):
    client = _make_client()
    response = MagicMock()
    response.headers = {}
    delay = client._parse_retry_after(response)
    self.assertEqual(delay, constant.DEFAULT_SLEEP_TIME)

  def test_falls_back_to_default_on_invalid_header(self):
    client = _make_client()
    response = MagicMock()
    response.headers = {"Retry-After": "not-a-number"}
    delay = client._parse_retry_after(response)
    self.assertEqual(delay, constant.DEFAULT_SLEEP_TIME)


class TestParseAndHandleResponse(unittest.TestCase):
  """Tests for _parse_and_handle_response."""

  def setUp(self):
    super().setUp()
    self.client = _make_client()

  def test_200_success(self):
    response = _make_response(200, json_data={"result": {"risk_events": []}})
    return_dict = {"status": False, "data": {}, "error": "", "retry": False, "response": None}
    result = self.client._parse_and_handle_response(
        return_dict, {"response": response}, "risk events"
    )
    self.assertTrue(result["status"])
    self.assertIn("result", result["data"])

  def test_401_raises_censys_exception(self):
    response = _make_response(401, text="Unauthorized")
    return_dict = {"status": False, "data": {}, "error": "", "retry": False, "response": None}
    with self.assertRaises(CensysException):
      self.client._parse_and_handle_response(
          return_dict, {"response": response}, "risk events"
      )

  def test_403_raises_censys_exception(self):
    response = _make_response(403, text="Forbidden")
    return_dict = {"status": False, "data": {}, "error": "", "retry": False, "response": None}
    with self.assertRaises(CensysException):
      self.client._parse_and_handle_response(
          return_dict, {"response": response}, "risk events"
      )

  def test_410_raises_censys_exception_with_cursor_message(self):
    response = _make_response(410, text="Gone")
    return_dict = {"status": False, "data": {}, "error": "", "retry": False, "response": None}
    with self.assertRaises(CensysException) as ctx:
      self.client._parse_and_handle_response(
          return_dict, {"response": response}, "risk events"
      )
    self.assertIn("410", ctx.exception.message)

  def test_429_sets_retry_true(self):
    response = _make_response(429, headers={"Retry-After": "10"}, text="Rate limit")
    response.json.side_effect = ValueError("no json")
    return_dict = {"status": False, "data": {}, "error": "", "retry": False, "response": None}
    result = self.client._parse_and_handle_response(
        return_dict, {"response": response}, "risk events"
    )
    self.assertFalse(result["status"])
    self.assertTrue(result["retry"])

  def test_503_sets_retry_true(self):
    response = _make_response(503, headers={"Retry-After": "5"}, text="Overload")
    response.json.side_effect = ValueError("no json")
    return_dict = {"status": False, "data": {}, "error": "", "retry": False, "response": None}
    result = self.client._parse_and_handle_response(
        return_dict, {"response": response}, "risk events"
    )
    self.assertFalse(result["status"])
    self.assertTrue(result["retry"])

  def test_500_sets_retry_true(self):
    response = _make_response(500, text="Internal server error")
    response.json.side_effect = ValueError("no json")
    return_dict = {"status": False, "data": {}, "error": "", "retry": False, "response": None}
    result = self.client._parse_and_handle_response(
        return_dict, {"response": response}, "risk events"
    )
    self.assertFalse(result["status"])
    self.assertTrue(result["retry"])

  def test_400_no_retry(self):
    response = _make_response(400, text="Bad request")
    response.json.side_effect = ValueError("no json")
    return_dict = {"status": False, "data": {}, "error": "", "retry": False, "response": None}
    result = self.client._parse_and_handle_response(
        return_dict, {"response": response}, "risk events"
    )
    self.assertFalse(result["status"])
    self.assertFalse(result.get("retry", False))

  def test_200_with_non_json_body_raises(self):
    response = MagicMock()
    response.status_code = 200
    response.text = "not-json"
    response.json.side_effect = ValueError("no json")
    return_dict = {"status": False, "data": {}, "error": "", "retry": False, "response": None}
    with self.assertRaises(CensysException):
      self.client._parse_and_handle_response(
          return_dict, {"response": response}, "risk events"
      )


class TestMakeApiCall(unittest.TestCase):
  """Tests for make_api_call."""

  def setUp(self):
    super().setUp()
    self.client = _make_client()

  @patch("censys_client.requests.request")
  def test_success_returns_data(self, mock_request):
    payload = {"result": {"risk_events": [{"id": "e1"}], "next_page_token": "tok"}}
    mock_request.return_value = _make_response(200, json_data=payload)

    result = self.client.make_api_call(
        "GET", "https://api.platform.censys.io/v1/supplychains/default/risk-events", {}
    )
    self.assertTrue(result["status"])
    self.assertIn("result", result["data"])

  @patch("censys_client.time.sleep")
  @patch("censys_client.requests.request")
  def test_retries_on_429_then_succeeds(self, mock_request, mock_sleep):
    payload = {"result": {"risk_events": [], "next_page_token": ""}}
    rate_limit_resp = MagicMock()
    rate_limit_resp.status_code = 429
    rate_limit_resp.headers = {"Retry-After": "1"}
    rate_limit_resp.text = "rate limited"
    rate_limit_resp.json.side_effect = ValueError("no json")

    success_resp = _make_response(200, json_data=payload)

    mock_request.side_effect = [rate_limit_resp, success_resp]

    result = self.client.make_api_call(
        "GET", "https://api.platform.censys.io/v1/supplychains/default/risk-events", {}
    )
    self.assertTrue(result["status"])
    self.assertEqual(mock_request.call_count, 2)

  @patch("censys_client.time.sleep")
  @patch("censys_client.requests.request")
  def test_retries_on_503_then_succeeds(self, mock_request, mock_sleep):
    payload = {"result": {"risk_events": [], "next_page_token": ""}}
    overload_resp = MagicMock()
    overload_resp.status_code = 503
    overload_resp.headers = {"Retry-After": "1"}
    overload_resp.text = "overload"
    overload_resp.json.side_effect = ValueError("no json")

    success_resp = _make_response(200, json_data=payload)
    mock_request.side_effect = [overload_resp, success_resp]

    result = self.client.make_api_call(
        "GET", "https://api.platform.censys.io/v1/supplychains/default/risk-events", {}
    )
    self.assertTrue(result["status"])

  @patch("censys_client.time.sleep")
  @patch("censys_client.requests.request")
  def test_raises_on_401(self, mock_request, mock_sleep):
    mock_request.return_value = _make_response(401, text="Unauthorized")
    with self.assertRaises(CensysException):
      self.client.make_api_call(
          "GET", "https://api.platform.censys.io/v1/supplychains/default/risk-events", {}
      )

  @patch("censys_client.time.sleep")
  @patch("censys_client.requests.request")
  def test_raises_on_410(self, mock_request, mock_sleep):
    mock_request.return_value = _make_response(410, text="Gone")
    with self.assertRaises(CensysException):
      self.client.make_api_call(
          "GET", "https://api.platform.censys.io/v1/supplychains/default/risk-events", {}
      )

  @patch("censys_client.time.sleep")
  @patch("censys_client.requests.request")
  def test_exhausts_retries_on_5xx(self, mock_request, mock_sleep):
    err_resp = MagicMock()
    err_resp.status_code = 500
    err_resp.headers = {}
    err_resp.text = "server error"
    err_resp.json.side_effect = ValueError("no json")
    mock_request.return_value = err_resp

    result = self.client.make_api_call(
        "GET", "https://api.platform.censys.io/v1/supplychains/default/risk-events", {}
    )
    self.assertFalse(result["status"])
    self.assertEqual(mock_request.call_count, constant.RETRY_COUNT)

  @patch("censys_client.time.sleep")
  def test_retries_on_connect_timeout(self, mock_sleep):
    client = _make_client()
    call_count = {"n": 0}

    @censys_client.exception_handler.exception_handler(action_name="Censys REST API")
    def fake_rest_api(self, method, url, params):
      call_count["n"] += 1
      if call_count["n"] < constant.RETRY_COUNT:
        raise MockConnectTimeout("timeout")
      return {
          "response": _make_response(200, json_data={"result": {}}),
          "status": True,
          "retry": False,
      }

    with patch.object(censys_client.CensysClient, "_censys_rest_api", fake_rest_api):
      client.make_api_call("GET", "https://example.com", {})

    # Should eventually succeed after retries
    self.assertGreater(call_count["n"], 1)


class TestBuildBaseFilterParams(unittest.TestCase):
  """Tests for _build_base_filter_params."""

  def setUp(self):
    super().setUp()
    self.client = _make_client()

  @patch("censys_client.utility.get_environment_variable", return_value="")
  def test_no_filters_set_returns_only_organization_id(self, mock_get_env):
    params = self.client._build_base_filter_params()
    self.assertEqual(params, {"organization_id": "org-uuid"})

  def test_change_types_normalized_to_lowercase(self):
    def side_effect(name):
      return "Opened| RESOLVED" if name == constant.ENV_CHANGE_TYPES else ""

    with patch("censys_client.utility.get_environment_variable", side_effect=side_effect):
      params = self.client._build_base_filter_params()
    self.assertEqual(params["change_types"], "opened,resolved")

  def test_severity_normalized_to_uppercase(self):
    def side_effect(name):
      return "high|critical" if name == constant.ENV_SEVERITY else ""

    with patch("censys_client.utility.get_environment_variable", side_effect=side_effect):
      params = self.client._build_base_filter_params()
    self.assertEqual(params["severity"], "HIGH,CRITICAL")

  def test_rapid_response_true_passed_through(self):
    def side_effect(name):
      return "true" if name == constant.ENV_RAPID_RESPONSE else ""

    with patch("censys_client.utility.get_environment_variable", side_effect=side_effect):
      params = self.client._build_base_filter_params()
    self.assertEqual(params["rapid_response"], "true")

  def test_invalid_rapid_response_raises_censys_exception(self):
    def side_effect(name):
      return "maybe" if name == constant.ENV_RAPID_RESPONSE else ""

    with patch("censys_client.utility.get_environment_variable", side_effect=side_effect):
      with self.assertRaises(CensysException):
        self.client._build_base_filter_params()

  def test_invalid_severity_raises_censys_exception(self):
    def side_effect(name):
      return "HIGH|BOGUS" if name == constant.ENV_SEVERITY else ""

    with patch("censys_client.utility.get_environment_variable", side_effect=side_effect):
      with self.assertRaises(CensysException):
        self.client._build_base_filter_params()

  def test_invalid_change_types_raises_censys_exception(self):
    def side_effect(name):
      return "opened|bogus" if name == constant.ENV_CHANGE_TYPES else ""

    with patch("censys_client.utility.get_environment_variable", side_effect=side_effect):
      with self.assertRaises(CensysException):
        self.client._build_base_filter_params()

  def test_valid_enum_filters_do_not_raise(self):
    def side_effect(name):
      if name == constant.ENV_SEVERITY:
        return "high|critical"
      if name == constant.ENV_CHANGE_TYPES:
        return "OPENED|Resolved"
      if name == constant.ENV_RAPID_RESPONSE:
        return "TRUE"
      return ""

    with patch("censys_client.utility.get_environment_variable", side_effect=side_effect):
      params = self.client._build_base_filter_params()
    self.assertEqual(params["severity"], "HIGH,CRITICAL")
    self.assertEqual(params["change_types"], "opened,resolved")
    self.assertEqual(params["rapid_response"], "true")

  def test_duplicate_severity_value_sent_once(self):
    def side_effect(name):
      return "HIGH|HIGH|CRITICAL" if name == constant.ENV_SEVERITY else ""

    with patch("censys_client.utility.get_environment_variable", side_effect=side_effect):
      params = self.client._build_base_filter_params()
    self.assertEqual(params["severity"], "HIGH,CRITICAL")

  def test_duplicate_change_types_value_sent_once(self):
    def side_effect(name):
      return "opened|Opened|OPENED" if name == constant.ENV_CHANGE_TYPES else ""

    with patch("censys_client.utility.get_environment_variable", side_effect=side_effect):
      params = self.client._build_base_filter_params()
    self.assertEqual(params["change_types"], "opened")


class TestParseRfc3339AndIsLater(unittest.TestCase):
  """Tests for _parse_rfc3339 and _is_later."""

  def setUp(self):
    super().setUp()
    self.client = _make_client()

  def test_parses_microsecond_precision(self):
    dt = self.client._parse_rfc3339("2026-10-08T02:48:15.154513Z")
    self.assertEqual(dt.microsecond, 154513)

  def test_truncates_nanosecond_precision(self):
    # 9 fractional digits — must truncate to 6 without raising.
    dt = self.client._parse_rfc3339("2026-08-11T00:26:33.279725054Z")
    self.assertEqual(dt.microsecond, 279725)

  def test_handles_no_fractional_seconds(self):
    dt = self.client._parse_rfc3339("2026-10-08T02:48:15Z")
    self.assertEqual(dt.microsecond, 0)

  def test_is_later_true_when_time_greater(self):
    self.assertTrue(
        self.client._is_later(
            "2026-10-08T02:00:00.000000Z", "id-a",
            "2026-10-08T01:00:00.000000Z", "id-b",
        )
    )

  def test_is_later_false_when_time_equal_and_id_not_greater(self):
    self.assertFalse(
        self.client._is_later(
            "2026-10-08T02:00:00.000000Z", "id-a",
            "2026-10-08T02:00:00.000000Z", "id-b",
        )
    )

  def test_is_later_true_when_time_equal_and_id_greater(self):
    self.assertTrue(
        self.client._is_later(
            "2026-10-08T02:00:00.000000Z", "id-c",
            "2026-10-08T02:00:00.000000Z", "id-b",
        )
    )

  def test_is_later_true_when_no_current_watermark(self):
    self.assertTrue(
        self.client._is_later("2026-10-08T02:00:00.000000Z", "id-a", None, None)
    )

  def test_is_later_false_when_candidate_time_missing(self):
    self.assertFalse(
        self.client._is_later(None, None, "2026-10-08T02:00:00.000000Z", "id-a")
    )


class TestGetRiskEventsPage(unittest.TestCase):
  """Tests for _get_risk_events_page."""

  def setUp(self):
    super().setUp()
    self.client = _make_client()
    self.base_params = {"organization_id": "org-uuid"}

  @patch("censys_client.CensysClient.make_api_call")
  def test_happy_path_returns_result(self, mock_call):
    events = [{"id": "e1"}, {"id": "e2"}]
    mock_call.return_value = {
        "status": True,
        "data": {
            "result": {
                "risk_events": events,
                "next_page_token": "tok2",
            }
        },
    }
    result = self.client._get_risk_events_page(
        base_params=self.base_params,
        page_token=None,
        supplier_ids=[],
        risk_type_ids=[],
        page_size=100,
    )
    self.assertEqual(result["risk_events"], events)
    self.assertEqual(result["next_page_token"], "tok2")

  @patch("censys_client.CensysClient.make_api_call")
  def test_raises_on_api_failure(self, mock_call):
    mock_call.return_value = {"status": False, "error": "some error"}
    with self.assertRaises(CensysException):
      self.client._get_risk_events_page(
          base_params=self.base_params,
          page_token=None,
          supplier_ids=[],
          risk_type_ids=[],
          page_size=100,
      )

  @patch("censys_client.CensysClient.make_api_call")
  def test_sends_page_token_when_provided(self, mock_call):
    mock_call.return_value = {
        "status": True,
        "data": {"result": {"risk_events": [], "next_page_token": "t2"}},
    }
    self.client._get_risk_events_page(
        base_params=self.base_params,
        page_token="prev-token",
        supplier_ids=[],
        risk_type_ids=[],
        page_size=100,
    )
    kwargs = mock_call.call_args[1]
    self.assertIn("params", kwargs)
    self.assertEqual(kwargs["params"]["page_token"], "prev-token")

  @patch("censys_client.CensysClient.make_api_call")
  def test_sends_supplier_ids_when_provided(self, mock_call):
    mock_call.return_value = {
        "status": True,
        "data": {"result": {"risk_events": [], "next_page_token": ""}},
    }
    self.client._get_risk_events_page(
        base_params=self.base_params,
        page_token=None,
        supplier_ids=["uuid-1", "uuid-2"],
        risk_type_ids=[],
        page_size=100,
    )
    kwargs = mock_call.call_args[1]
    self.assertIn("supplier_ids", kwargs["params"])
    self.assertEqual(kwargs["params"]["supplier_ids"], "uuid-1,uuid-2")

  @patch("censys_client.CensysClient.make_api_call")
  def test_sends_risk_type_ids_when_provided(self, mock_call):
    mock_call.return_value = {
        "status": True,
        "data": {"result": {"risk_events": [], "next_page_token": ""}},
    }
    self.client._get_risk_events_page(
        base_params=self.base_params,
        page_token=None,
        supplier_ids=[],
        risk_type_ids=["CENSYS-2022-1064", "CVE-2021-44228"],
        page_size=100,
    )
    kwargs = mock_call.call_args[1]
    self.assertIn("risk_type_ids", kwargs["params"])
    self.assertEqual(
        kwargs["params"]["risk_type_ids"], "CENSYS-2022-1064,CVE-2021-44228"
    )

  @patch("censys_client.CensysClient.make_api_call")
  def test_carries_base_params_onto_every_page(self, mock_call):
    mock_call.return_value = {
        "status": True,
        "data": {"result": {"risk_events": [], "next_page_token": ""}},
    }
    base_params = {
        "organization_id": "org-uuid",
        "inserted_after_time": "2026-10-08T00:00:00.000000Z",
        "severity": "HIGH,CRITICAL",
    }
    self.client._get_risk_events_page(
        base_params=base_params,
        page_token=None,
        supplier_ids=[],
        risk_type_ids=[],
        page_size=100,
    )
    kwargs = mock_call.call_args[1]
    self.assertEqual(
        kwargs["params"]["inserted_after_time"], "2026-10-08T00:00:00.000000Z"
    )
    self.assertEqual(kwargs["params"]["severity"], "HIGH,CRITICAL")

  @patch("censys_client.CensysClient.make_api_call")
  def test_url_targets_default_supply_chain(self, mock_call):
    mock_call.return_value = {
        "status": True,
        "data": {"result": {"risk_events": [], "next_page_token": ""}},
    }
    self.client._get_risk_events_page(
        base_params=self.base_params,
        page_token=None,
        supplier_ids=[],
        risk_type_ids=[],
        page_size=100,
    )
    args = mock_call.call_args[0]
    # make_api_call("GET", url, params=..., fetch_type=...)
    self.assertIn("/v1/supplychains/default/risk-events", args[1])


class TestFetchRiskEvents(unittest.TestCase):
  """Integration-level tests for fetch_risk_events."""

  def _make_page_result(self, events, next_token):
    return {
        "risk_events": events,
        "next_page_token": next_token,
    }

  def _checkpoint_values(self, mock_set_cp, key):
    return [c.args[2] for c in mock_set_cp.call_args_list if c.args[1] == key]

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint")
  @patch("censys_client.CensysClient._ingest_events")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_single_page_empty_next_token(
      self, mock_get_page, mock_ingest, mock_get_cp, mock_set_cp
  ):
    # Use an explicit, far-past existing checkpoint so this test's
    # correctness never depends on how CENSYS_LOOKBACK_DAYS seeding compares
    # against the real wall clock at run time.
    mock_get_cp.side_effect = ["2000-01-01T00:00:00.000000Z", None]
    events = [_make_event("e1", "2026-10-08T02:48:15.000000Z")]
    mock_get_page.return_value = self._make_page_result(events, "")

    client = _make_client()
    client.fetch_risk_events()

    mock_get_page.assert_called_once()
    mock_ingest.assert_called_once_with(events)

    time_values = self._checkpoint_values(
        mock_set_cp, constant.CHECKPOINT_KEY_INSERTED_AFTER_TIME
    )
    self.assertEqual(time_values[-1], "2026-10-08T02:48:15.000000Z")
    id_values = self._checkpoint_values(
        mock_set_cp, constant.CHECKPOINT_KEY_INSERTED_AFTER_EVENT_ID
    )
    self.assertEqual(id_values[-1], "e1")

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint")
  @patch("censys_client.CensysClient._ingest_events")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_resumes_from_checkpoint_watermark(
      self, mock_get_page, mock_ingest, mock_get_cp, mock_set_cp
  ):
    mock_get_cp.side_effect = ["stored-time", "stored-id"]
    mock_get_page.return_value = self._make_page_result([], "")

    client = _make_client()
    client.fetch_risk_events()

    call_kwargs = mock_get_page.call_args.kwargs
    self.assertEqual(
        call_kwargs["base_params"]["inserted_after_time"], "stored-time"
    )
    self.assertEqual(
        call_kwargs["base_params"]["inserted_after_event_id"], "stored-id"
    )

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.CensysClient._ingest_events")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_first_run_seeds_from_inserted_after_time_and_omits_event_id(
      self, mock_get_page, mock_ingest, mock_get_cp, mock_set_cp
  ):
    mock_get_page.return_value = self._make_page_result([], "")

    client = _make_client(inserted_after_time="2020-05-01T00:00:00Z")
    client.fetch_risk_events()

    call_kwargs = mock_get_page.call_args.kwargs
    self.assertEqual(
        call_kwargs["base_params"]["inserted_after_time"], "2020-05-01T00:00:00Z"
    )
    self.assertNotIn("inserted_after_event_id", call_kwargs["base_params"])

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.CensysClient._ingest_events")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_first_run_falls_back_to_default_when_inserted_after_time_unset(
      self, mock_get_page, mock_ingest, mock_get_cp, mock_set_cp
  ):
    mock_get_page.return_value = self._make_page_result([], "")

    client = _make_client(inserted_after_time=None)
    client.fetch_risk_events()

    call_kwargs = mock_get_page.call_args.kwargs
    self.assertEqual(
        call_kwargs["base_params"]["inserted_after_time"],
        constant.DEFAULT_VALUES.get(constant.ENV_INSERTED_AFTER_TIME),
    )

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.CensysClient._ingest_events")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_multiple_pages_until_next_token_empty(
      self, mock_get_page, mock_ingest, mock_get_cp, mock_set_cp
  ):
    mock_get_page.side_effect = [
        self._make_page_result(
            [_make_event("e1", "2026-10-08T01:00:00.000000Z")], "tok1"
        ),
        self._make_page_result(
            [_make_event("e2", "2026-10-08T02:00:00.000000Z")], "tok2"
        ),
        self._make_page_result([], ""),
    ]

    client = _make_client()
    client.fetch_risk_events()

    self.assertEqual(mock_get_page.call_count, 3)
    self.assertEqual(mock_ingest.call_count, 2)  # Only called when events present

    second_call_kwargs = mock_get_page.call_args_list[1].kwargs
    self.assertEqual(second_call_kwargs["page_token"], "tok1")
    third_call_kwargs = mock_get_page.call_args_list[2].kwargs
    self.assertEqual(third_call_kwargs["page_token"], "tok2")

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint")
  @patch("censys_client.CensysClient._ingest_events")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_watermark_advances_to_latest_inserted_at_across_page(
      self, mock_get_page, mock_ingest, mock_get_cp, mock_set_cp
  ):
    # Explicit far-past checkpoint — see comment in
    # test_single_page_empty_next_token for why.
    mock_get_cp.side_effect = ["2000-01-01T00:00:00.000000Z", None]
    # Events out of order within a page — watermark should track the max,
    # not just the last element.
    events = [
        _make_event("e1", "2026-10-08T01:00:00.000000Z"),
        _make_event("e2", "2026-10-08T03:00:00.000000Z"),
        _make_event("e3", "2026-10-08T02:00:00.000000Z"),
    ]
    mock_get_page.return_value = self._make_page_result(events, "")

    client = _make_client()
    client.fetch_risk_events()

    time_values = self._checkpoint_values(
        mock_set_cp, constant.CHECKPOINT_KEY_INSERTED_AFTER_TIME
    )
    self.assertEqual(time_values[-1], "2026-10-08T03:00:00.000000Z")
    id_values = self._checkpoint_values(
        mock_set_cp, constant.CHECKPOINT_KEY_INSERTED_AFTER_EVENT_ID
    )
    self.assertEqual(id_values[-1], "e2")

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_raises_censys_exception_on_api_error(
      self, mock_get_page, mock_get_cp, mock_set_cp
  ):
    mock_get_page.side_effect = CensysException("API error")

    client = _make_client()
    with self.assertRaises(CensysException):
      client.fetch_risk_events()

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.CensysClient._ingest_events")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_runtime_exceeded_propagates(
      self, mock_get_page, mock_ingest, mock_get_cp, mock_set_cp
  ):
    mock_get_page.return_value = self._make_page_result(
        [_make_event("e1", "2026-10-08T01:00:00.000000Z")], "tok1"
    )
    mock_ingest.side_effect = RunTimeExceeded("Time up")

    client = _make_client()
    with self.assertRaises(RunTimeExceeded):
      client.fetch_risk_events()

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.CensysClient._ingest_events")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_unknown_exception_propagates(
      self, mock_get_page, mock_ingest, mock_get_cp, mock_set_cp
  ):
    mock_get_page.return_value = self._make_page_result(
        [_make_event("e1", "2026-10-08T01:00:00.000000Z")], "tok1"
    )
    mock_ingest.side_effect = ValueError("unexpected")

    client = _make_client()
    with self.assertRaises(ValueError):
      client.fetch_risk_events()

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.CensysClient._ingest_events")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_empty_events_still_checkpoints_and_stops(
      self, mock_get_page, mock_ingest, mock_get_cp, mock_set_cp
  ):
    mock_get_page.return_value = self._make_page_result([], "")

    client = _make_client()
    client.fetch_risk_events()

    mock_get_page.assert_called_once()
    mock_ingest.assert_not_called()

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.CensysClient._ingest_events")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_page_size_is_fixed_default(
      self, mock_get_page, mock_ingest, mock_get_cp, mock_set_cp
  ):
    mock_get_page.return_value = self._make_page_result([], "")

    client = _make_client()
    client.fetch_risk_events()

    call_kwargs = mock_get_page.call_args.kwargs
    self.assertEqual(call_kwargs["page_size"], constant.DEFAULT_PAGE_SIZE)

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.CensysClient._resolve_supplier_ids")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_aborts_when_all_supplier_names_invalid(
      self, mock_get_page, mock_resolve_suppliers, mock_get_cp, mock_set_cp
  ):
    # All configured supplier names failed to resolve — _resolve_supplier_ids
    # raises CensysException, which must propagate out of fetch_risk_events
    # rather than being swallowed as a tolerable "proceed without filter".
    mock_resolve_suppliers.side_effect = CensysException(
        "CENSYS_SUPPLIER_NAMES contains 1 name(s) and none resolved"
    )

    client = _make_client(supplier_names="Nonexistent Supplier")
    with self.assertRaises(CensysException):
      client.fetch_risk_events()
    mock_get_page.assert_not_called()

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.CensysClient._resolve_risk_type_ids")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_aborts_when_all_risk_names_invalid(
      self, mock_get_page, mock_resolve_risks, mock_get_cp, mock_set_cp
  ):
    mock_resolve_risks.side_effect = CensysException(
        "CENSYS_RISK_NAMES contains 1 name(s) and none resolved"
    )

    client = _make_client(risk_names="Nonexistent Risk")
    with self.assertRaises(CensysException):
      client.fetch_risk_events()
    mock_get_page.assert_not_called()

  @patch("censys_client.utility.set_last_checkpoint")
  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.CensysClient._ingest_events")
  @patch("censys_client.CensysClient._resolve_supplier_ids")
  @patch("censys_client.CensysClient._get_risk_events_page")
  def test_proceeds_when_supplier_resolution_partially_succeeds(
      self, mock_get_page, mock_resolve_suppliers, mock_ingest, mock_get_cp, mock_set_cp
  ):
    mock_resolve_suppliers.return_value = ["sup-b"]
    mock_get_page.return_value = self._make_page_result([], "")

    client = _make_client(supplier_names="Supplier A|Supplier B")
    client.fetch_risk_events()

    call_kwargs = mock_get_page.call_args.kwargs
    self.assertEqual(call_kwargs["supplier_ids"], ["sup-b"])


class TestIngestEvents(unittest.TestCase):
  """Tests for _ingest_events."""

  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.ingest_v1.ingest")
  def test_ingest_called_with_events(self, mock_ingest, mock_get_cp):
    client = _make_client()
    events = [{"id": f"e{i}"} for i in range(5)]
    client._ingest_events(events)
    mock_ingest.assert_called_once()
    call_args = mock_ingest.call_args[0]
    self.assertEqual(call_args[0], events)
    self.assertEqual(call_args[1], constant.GOOGLE_SECOPS_DATA_TYPE)

  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.ingest_v1.ingest")
  def test_empty_events_skips_ingest(self, mock_ingest, mock_get_cp):
    client = _make_client()
    client._ingest_events([])
    mock_ingest.assert_not_called()

  @patch("censys_client.time.time", return_value=time.time() + 60 * 60)
  @patch(
      "censys_client.utility.get_last_checkpoint",
      return_value=str(time.time()),
  )
  @patch("censys_client.ingest_v1.ingest")
  def test_raises_runtime_exceeded_when_budget_exceeded(
      self, mock_ingest, mock_get_cp, mock_time
  ):
    client = _make_client()
    events = [{"id": "e1"}]
    with self.assertRaises(RunTimeExceeded):
      client._ingest_events(events)

  @patch("censys_client.utility.get_last_checkpoint", return_value=None)
  @patch("censys_client.ingest_v1.ingest")
  def test_batches_large_event_lists(self, mock_ingest, mock_get_cp):
    client = _make_client()
    events = [{"id": f"e{i}"} for i in range(1500)]
    client._ingest_events(events)
    # Should be called twice (1000 + 500)
    self.assertEqual(mock_ingest.call_count, 2)


class TestListAllSuppliers(unittest.TestCase):
  """Tests for _list_all_suppliers."""

  def setUp(self):
    super().setUp()
    self.client = _make_client()

  @patch("censys_client.CensysClient.make_api_call")
  def test_paginates_until_next_page_token_empty(self, mock_call):
    mock_call.side_effect = [
        {
            "status": True,
            "data": {
                "result": {
                    "suppliers": [{"id": "sup-1", "display_name": "Supplier One"}],
                    "next_page_token": "tok1",
                }
            },
        },
        {
            "status": True,
            "data": {
                "result": {
                    "suppliers": [{"id": "sup-2", "display_name": "Supplier Two"}],
                    "next_page_token": "",
                }
            },
        },
    ]

    all_suppliers = self.client._list_all_suppliers()

    self.assertEqual(mock_call.call_count, 2)
    self.assertEqual(len(all_suppliers), 2)
    self.assertEqual(all_suppliers[0]["id"], "sup-1")
    self.assertEqual(all_suppliers[1]["id"], "sup-2")
    second_call_kwargs = mock_call.call_args_list[1][1]
    self.assertEqual(second_call_kwargs["params"]["page_token"], "tok1")

  @patch("censys_client.CensysClient.make_api_call")
  def test_single_page_no_pagination_needed(self, mock_call):
    mock_call.return_value = {
        "status": True,
        "data": {
            "result": {
                "suppliers": [{"id": "sup-a", "display_name": "Supplier A"}],
                "next_page_token": "",
            }
        },
    }

    all_suppliers = self.client._list_all_suppliers()

    self.assertEqual(len(all_suppliers), 1)
    mock_call.assert_called_once()

  @patch("censys_client.CensysClient.make_api_call")
  def test_sends_max_page_size(self, mock_call):
    mock_call.return_value = {
        "status": True,
        "data": {"result": {"suppliers": [], "next_page_token": ""}},
    }

    self.client._list_all_suppliers()

    kwargs = mock_call.call_args[1]
    self.assertEqual(kwargs["params"]["page_size"], constant.MAX_SUPPLIERS_PAGE_SIZE)

  @patch("censys_client.CensysClient.make_api_call")
  def test_targets_default_supply_chain(self, mock_call):
    mock_call.return_value = {
        "status": True,
        "data": {"result": {"suppliers": [], "next_page_token": ""}},
    }

    self.client._list_all_suppliers()

    args = mock_call.call_args[0]
    self.assertIn("/v1/supplychains/default/suppliers", args[1])

  @patch("censys_client.CensysClient.make_api_call")
  def test_raises_on_api_failure(self, mock_call):
    mock_call.return_value = {"status": False, "error": "some error"}
    with self.assertRaises(CensysException):
      self.client._list_all_suppliers()


class TestResolveSupplierIds(unittest.TestCase):
  """Tests for _resolve_supplier_ids."""

  def setUp(self):
    super().setUp()
    self.client = _make_client(supplier_names="Supplier A|Supplier B")

  @patch("censys_client.CensysClient._save_supplier_cache")
  @patch("censys_client.CensysClient._load_supplier_cache")
  @patch("censys_client.CensysClient._list_all_suppliers")
  def test_resolves_names_to_ids(
      self, mock_list_suppliers, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_suppliers.return_value = [
        {"id": "sup-a", "display_name": "Supplier A"},
        {"id": "sup-b", "display_name": "Supplier B"},
    ]

    result = self.client._resolve_supplier_ids()
    self.assertIn("sup-a", result)
    self.assertIn("sup-b", result)
    mock_list_suppliers.assert_called_once()

  @patch("censys_client.CensysClient._save_supplier_cache")
  @patch("censys_client.CensysClient._load_supplier_cache")
  def test_returns_cached_ids_without_api_call(self, mock_load_cache, mock_save_cache):
    mock_load_cache.return_value = {
        "Supplier A": {"supplier_id": "cached-a"},
        "Supplier B": {"supplier_id": "cached-b"},
    }

    result = self.client._resolve_supplier_ids()
    self.assertIn("cached-a", result)
    self.assertIn("cached-b", result)

  @patch("censys_client.CensysClient._save_supplier_cache")
  @patch("censys_client.CensysClient._load_supplier_cache")
  @patch("censys_client.CensysClient._list_all_suppliers")
  def test_warns_and_skips_ambiguous_names(
      self, mock_list_suppliers, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_suppliers.return_value = [
        {"id": "s1", "display_name": "Supplier A"},
        {"id": "s2", "display_name": "Supplier A"},  # duplicate
        {"id": "s3", "display_name": "Supplier B"},
    ]

    result = self.client._resolve_supplier_ids()
    # Supplier A is ambiguous — should be skipped; Supplier B should be included
    self.assertNotIn("s1", result)
    self.assertNotIn("s2", result)
    self.assertIn("s3", result)

  @patch("censys_client.CensysClient._save_supplier_cache")
  @patch("censys_client.CensysClient._load_supplier_cache")
  @patch("censys_client.CensysClient._list_all_suppliers")
  def test_raises_when_all_supplier_names_invalid(
      self, mock_list_suppliers, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_suppliers.return_value = [{"id": "s9", "display_name": "Someone Else"}]

    with self.assertRaises(CensysException):
      self.client._resolve_supplier_ids()

  @patch("censys_client.CensysClient._save_supplier_cache")
  @patch("censys_client.CensysClient._load_supplier_cache")
  @patch("censys_client.CensysClient._list_all_suppliers")
  def test_does_not_raise_when_at_least_one_name_resolves(
      self, mock_list_suppliers, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_suppliers.return_value = [{"id": "sup-b", "display_name": "Supplier B"}]

    # "Supplier A" does not match anything, "Supplier B" does — partial
    # success must proceed with what resolved, not raise.
    result = self.client._resolve_supplier_ids()
    self.assertEqual(result, ["sup-b"])

  @patch("censys_client.CensysClient._save_supplier_cache")
  @patch("censys_client.CensysClient._load_supplier_cache")
  @patch("censys_client.CensysClient._list_all_suppliers")
  def test_raises_on_catalog_fetch_failure(
      self, mock_list_suppliers, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_suppliers.side_effect = CensysException("API down")

    # A non-200/error response from the list-suppliers endpoint must abort
    # the run rather than silently proceeding without a supplier filter.
    with self.assertRaises(CensysException):
      self.client._resolve_supplier_ids()

  def test_returns_empty_when_no_supplier_names(self):
    client = _make_client(supplier_names="")
    result = client._resolve_supplier_ids()
    self.assertEqual(result, [])

  @patch("censys_client.CensysClient._save_supplier_cache")
  @patch("censys_client.CensysClient._load_supplier_cache")
  @patch("censys_client.CensysClient._list_all_suppliers")
  def test_duplicate_name_resolves_to_single_id(
      self, mock_list_suppliers, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_suppliers.return_value = [
        {"id": "sup-a", "display_name": "Supplier A"},
    ]

    client = _make_client(supplier_names="Supplier A|Supplier A|Supplier A")
    result = client._resolve_supplier_ids()
    self.assertEqual(result, ["sup-a"])
    mock_list_suppliers.assert_called_once()

  @patch("censys_client.CensysClient._save_supplier_cache")
  @patch("censys_client.CensysClient._load_supplier_cache")
  def test_duplicate_cached_name_resolves_to_single_id(
      self, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {
        "Supplier A": {"supplier_id": "cached-a"},
    }

    client = _make_client(supplier_names="Supplier A|Supplier A")
    result = client._resolve_supplier_ids()
    self.assertEqual(result, ["cached-a"])


class TestListAllRisks(unittest.TestCase):
  """Tests for _list_all_risks."""

  def setUp(self):
    super().setUp()
    self.client = _make_client()

  @patch("censys_client.CensysClient.make_api_call")
  def test_paginates_until_next_page_token_empty(self, mock_call):
    mock_call.side_effect = [
        {
            "status": True,
            "data": {
                "result": {
                    "risks": [{"id": "CENSYS-1", "name": "Risk One"}],
                    "next_page_token": "tok1",
                }
            },
        },
        {
            "status": True,
            "data": {
                "result": {
                    "risks": [{"id": "CENSYS-2", "name": "Risk Two"}],
                    "next_page_token": "",
                }
            },
        },
    ]

    all_risks = self.client._list_all_risks()

    self.assertEqual(mock_call.call_count, 2)
    self.assertEqual(len(all_risks), 2)
    self.assertEqual(all_risks[0]["id"], "CENSYS-1")
    self.assertEqual(all_risks[1]["id"], "CENSYS-2")
    second_call_kwargs = mock_call.call_args_list[1][1]
    self.assertEqual(second_call_kwargs["params"]["page_token"], "tok1")

  @patch("censys_client.CensysClient.make_api_call")
  def test_targets_default_supply_chain(self, mock_call):
    mock_call.return_value = {
        "status": True,
        "data": {"result": {"risks": [], "next_page_token": ""}},
    }

    self.client._list_all_risks()

    args = mock_call.call_args[0]
    self.assertIn("/v1/supplychains/default/risks", args[1])

  @patch("censys_client.CensysClient.make_api_call")
  def test_raises_on_api_failure(self, mock_call):
    mock_call.return_value = {"status": False, "error": "some error"}
    with self.assertRaises(CensysException):
      self.client._list_all_risks()


class TestResolveRiskTypeIds(unittest.TestCase):
  """Tests for _resolve_risk_type_ids."""

  def setUp(self):
    super().setUp()
    self.client = _make_client(risk_names="Exposed SMTP Service|Weak TLS Cipher")

  @patch("censys_client.CensysClient._save_risk_name_cache")
  @patch("censys_client.CensysClient._load_risk_name_cache")
  @patch("censys_client.CensysClient._list_all_risks")
  def test_resolves_names_to_ids(
      self, mock_list_risks, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_risks.return_value = [
        {"id": "CENSYS-2022-1064", "name": "Exposed SMTP Service"},
        {"id": "CENSYS-2023-2001", "name": "Weak TLS Cipher"},
    ]

    result = self.client._resolve_risk_type_ids()
    self.assertIn("CENSYS-2022-1064", result)
    self.assertIn("CENSYS-2023-2001", result)
    mock_list_risks.assert_called_once()

  @patch("censys_client.CensysClient._save_risk_name_cache")
  @patch("censys_client.CensysClient._load_risk_name_cache")
  def test_returns_cached_ids_without_api_call(
      self, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {
        "Exposed SMTP Service": {"risk_type_id": "cached-1"},
        "Weak TLS Cipher": {"risk_type_id": "cached-2"},
    }

    result = self.client._resolve_risk_type_ids()
    self.assertIn("cached-1", result)
    self.assertIn("cached-2", result)

  @patch("censys_client.CensysClient._save_risk_name_cache")
  @patch("censys_client.CensysClient._load_risk_name_cache")
  @patch("censys_client.CensysClient._list_all_risks")
  def test_warns_and_skips_ambiguous_names(
      self, mock_list_risks, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_risks.return_value = [
        {"id": "r1", "name": "Exposed SMTP Service"},
        {"id": "r2", "name": "Exposed SMTP Service"},  # duplicate
        {"id": "r3", "name": "Weak TLS Cipher"},
    ]

    result = self.client._resolve_risk_type_ids()
    # "Exposed SMTP Service" is ambiguous — should be skipped.
    self.assertNotIn("r1", result)
    self.assertNotIn("r2", result)
    self.assertIn("r3", result)

  @patch("censys_client.CensysClient._save_risk_name_cache")
  @patch("censys_client.CensysClient._load_risk_name_cache")
  @patch("censys_client.CensysClient._list_all_risks")
  def test_warns_and_skips_unmatched_names(
      self, mock_list_risks, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_risks.return_value = [
        {"id": "r3", "name": "Weak TLS Cipher"},
    ]

    result = self.client._resolve_risk_type_ids()
    # "Exposed SMTP Service" never matched anything in the catalog and is
    # excluded; "Weak TLS Cipher" matched and resolves to "r3".
    self.assertEqual(result, ["r3"])

  @patch("censys_client.CensysClient._save_risk_name_cache")
  @patch("censys_client.CensysClient._load_risk_name_cache")
  @patch("censys_client.CensysClient._list_all_risks")
  def test_raises_when_all_risk_names_invalid(
      self, mock_list_risks, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_risks.return_value = [
        {"id": "r9", "name": "Some Other Risk"},
    ]

    with self.assertRaises(CensysException):
      self.client._resolve_risk_type_ids()

  @patch("censys_client.CensysClient._save_risk_name_cache")
  @patch("censys_client.CensysClient._load_risk_name_cache")
  @patch("censys_client.CensysClient._list_all_risks")
  def test_raises_on_catalog_fetch_failure(
      self, mock_list_risks, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_risks.side_effect = CensysException("API down")

    # A non-200/error response from the list-risks endpoint must abort the
    # run rather than silently proceeding without a risk-type filter.
    with self.assertRaises(CensysException):
      self.client._resolve_risk_type_ids()

  def test_returns_empty_when_no_risk_names(self):
    client = _make_client(risk_names="")
    result = client._resolve_risk_type_ids()
    self.assertEqual(result, [])

  @patch("censys_client.CensysClient._save_risk_name_cache")
  @patch("censys_client.CensysClient._load_risk_name_cache")
  @patch("censys_client.CensysClient._list_all_risks")
  def test_duplicate_name_resolves_to_single_id(
      self, mock_list_risks, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {}
    mock_list_risks.return_value = [
        {"id": "CENSYS-2022-1064", "name": "Exposed SMTP Service"},
    ]

    client = _make_client(
        risk_names="Exposed SMTP Service|Exposed SMTP Service|Exposed SMTP Service"
    )
    result = client._resolve_risk_type_ids()
    self.assertEqual(result, ["CENSYS-2022-1064"])
    mock_list_risks.assert_called_once()

  @patch("censys_client.CensysClient._save_risk_name_cache")
  @patch("censys_client.CensysClient._load_risk_name_cache")
  def test_duplicate_cached_name_resolves_to_single_id(
      self, mock_load_cache, mock_save_cache
  ):
    mock_load_cache.return_value = {
        "Exposed SMTP Service": {"risk_type_id": "cached-1"},
    }

    client = _make_client(risk_names="Exposed SMTP Service|Exposed SMTP Service")
    result = client._resolve_risk_type_ids()
    self.assertEqual(result, ["cached-1"])


if __name__ == "__main__":
  unittest.main()
