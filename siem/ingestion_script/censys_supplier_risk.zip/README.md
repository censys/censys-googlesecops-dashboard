# Censys Supplier Risk — Google SecOps SIEM Connector

Polls the Censys Supplier Risk API for supply-chain risk events
(`opened`, `resolved`, `reopened`) and ingests them into Google Chronicle SecOps
SIEM as `CENSYS_SUPPLIER_RISK_CUSTOM` log entries.

---

## Overall Flow

```
Cloud Scheduler (cron) → Cloud Function → Censys /v1/risk-events → Chronicle Ingestion API
                          ↕ GCS Bucket (checkpoint / process lock)
```

1. Cloud Scheduler triggers the Cloud Function on the configured cron schedule.
2. The function acquires a GCS-backed process lock to prevent overlapping
   executions.
3. If `CENSYS_SUPPLIER_NAMES` is set, supplier display names are resolved to
   UUIDs via `GET /v1/supplychains/default/suppliers` — `default` resolves
   server-side to the organization's primary supply chain, so no separate
   list-supply-chains call is made. If `CENSYS_RISK_NAMES` is set, risk display
   names are resolved to `risk_type_id`s the same way, via
   `GET /v1/supplychains/default/risks` (paginated — this endpoint has no
   name/keyword search, so the full catalog is read to find matches).
4. The function reads the stored
   `(inserted_after_time, inserted_after_event_id)` watermark from GCS (or seeds
   `inserted_after_time` directly from `CENSYS_INSERTED_AFTER_TIME` on the first
   run — default `1970-01-01T00:00:00Z`, i.e. full history) and fetches one page
   at a time from `GET /v1/supplychains/default/risk-events`, paginating within
   the run via `page_token`.
5. Each page is ingested into Google Chronicle via `ingest_v1.ingest()`.
6. After each successful ingest, the watermark is advanced to the latest
   `(inserted_at, id)` seen across all events returned on that page and
   checkpointed to GCS.
7. When `next_page_token` is empty, the connector exits cleanly and waits for
   the next scheduled invocation.

---

## Pre-requisites

### GCP Permissions for the Service Account

The Compute Engine default service account (or a custom SA) needs:

| Role | Purpose |
|------|---------|
| `roles/storage.admin` | Read/write GCS checkpoint file |
| `roles/secretmanager.secretAccessor` | Read API token from Secret Manager |
| `roles/chronicle.editor` | Ingest logs into Google SecOps |
| `roles/cloudscheduler.jobRunner` | Allow Scheduler to invoke the function |
| `roles/run.invoker` | Allow Scheduler to call the Gen 2 Cloud Function |

### GCP Services to Enable

- `cloudfunctions.googleapis.com`
- `run.googleapis.com`
- `cloudbuild.googleapis.com`
- `secretmanager.googleapis.com`
- `storage-component.googleapis.com`
- `cloudscheduler.googleapis.com`
- `chronicle.googleapis.com`
- `cloudresourcemanager.googleapis.com`

### Source Product Credentials

- A Censys Personal Access Token (PAT) scoped to Supply Chain Intelligence
  in the Censys Platform UI.
- The organization UUID (`CENSYS_ORGANIZATION_ID`) from your Censys account.

---

## Creating the ZIP

```bash
# From the plugin root (censys_supplier_risk_intelligence/)
zip -r censys_sr_function.zip . -x "*.pyc" -x ".git/*"
```

Include the `common/` directory at the same level — it is a required dependency.

---

## Automatic Deployment

Use the provided interactive shell script:

```bash
bash censys_deploy.sh
```

The script will:
1. Prompt for all required configuration values.
2. Enable required GCP APIs.
3. Grant IAM roles to the default compute service account.
4. Create a GCS bucket for checkpoints.
5. Store `CENSYS_API_KEY` (and optionally `CHRONICLE_SERVICE_ACCOUNT`) in Secret
   Manager.
6. Upload the function ZIP to GCS and deploy the Cloud Function (Gen 2,
   python312).
7. Create a Cloud Scheduler job with the configured cron schedule.

---

## Manual Deployment

### 1. Enable Required APIs

```bash
gcloud services enable \
  cloudfunctions.googleapis.com run.googleapis.com cloudbuild.googleapis.com \
  artifactregistry.googleapis.com secretmanager.googleapis.com \
  storage-component.googleapis.com cloudscheduler.googleapis.com \
  chronicle.googleapis.com cloudresourcemanager.googleapis.com \
  --project=<PROJECT_ID>
```

### 2. Store the PAT in Secret Manager

```bash
echo -n "<YOUR_CENSYS_PAT>" | \
  gcloud secrets create censys-api-key \
    --replication-policy=automatic \
    --data-file=- \
    --project=<PROJECT_ID>

SECRET_ID=$(gcloud secrets versions describe latest \
  --secret=censys-api-key \
  --project=<PROJECT_ID> \
  --format='value(name)')
```

### 3. Create a GCS Bucket

```bash
gcloud storage buckets create gs://<BUCKET_NAME> --project=<PROJECT_ID> \
  --location=<REGION>
```

### 4. Deploy the Cloud Function

```bash
gcloud functions deploy censys-sr-secops-function \
  --gen2 \
  --runtime python312 \
  --region=<REGION> \
  --source=gs://<BUCKET_NAME>/censys_sr_function.zip \
  --entry-point=main \
  --trigger-http \
  --no-allow-unauthenticated \
  --memory=8GiB \
  --timeout=3600s \
  --set-env-vars="\
CHRONICLE_CUSTOMER_ID=<CHRONICLE_CUSTOMER_ID>,\
CHRONICLE_PROJECT_NUMBER=<CHRONICLE_PROJECT_NUMBER>,\
CHRONICLE_REGION=<CHRONICLE_REGION>,\
GCP_BUCKET_NAME=<BUCKET_NAME>,\
CENSYS_API_KEY=<SECRET_RESOURCE_ID>,\
CENSYS_ORGANIZATION_ID=<ORG_UUID>,\
CENSYS_INSERTED_AFTER_TIME=1970-01-01T00:00:00Z,\
CENSYS_SEVERITY=HIGH|CRITICAL,\
CENSYS_CHANGE_TYPES=opened|resolved|reopened,\
CENSYS_SUPPLIER_NAMES=,\
CENSYS_RISK_NAMES=,\
CENSYS_RAPID_RESPONSE=" \
  --project=<PROJECT_ID>
```

(The last four are optional filters — left blank above means "include
everything" for that dimension. Set only the ones you want to narrow.
Multi-value filters use `|` (pipe), not comma, as the delimiter between values —
see the table below for why: `gcloud ... --set-env-vars` itself uses comma to
separate different `KEY=VALUE` pairs, so a comma inside a value (e.g.
`HIGH,CRITICAL`) is misparsed as the start of a new env var.)

### 5. Create Cloud Scheduler Job

```bash
gcloud scheduler jobs create http censys-sr-secops-scheduler \
  --schedule="*/5 * * * *" \
  --uri="<CLOUD_FUNCTION_URI>" \
  --http-method=POST \
  --oidc-service-account-email=<SA_EMAIL> \
  --location=<REGION> \
  --time-zone=UTC \
  --attempt-deadline=1m \
  --project=<PROJECT_ID>
```

---

## Environment Variables

Both the variable's **name** and its **value** tolerate stray leading/trailing
whitespace. A manual edit after deployment (e.g. via the GCP Console's
"Variables and secrets" editor) can leave spaces around the name itself, e.g.
`"  CENSYS_INSERTED_AFTER_TIME  "` instead of `CENSYS_INSERTED_AFTER_TIME` —
`utility.get_environment_variable` resolves this to the correct variable rather
than treating it as unset. An exact (unpadded) key match is always preferred if
both happen to exist.

| Variable | Description | Required | Type | Default | Secret |
|----------|-------------|----------|------|---------|--------|
| `CENSYS_API_KEY` | Censys Personal Access Token (PAT). Sent as `Authorization: Bearer <token>` on every request. | Yes | string (Secret Manager path) | — | Yes |
| `CENSYS_ORGANIZATION_ID` | The ID of a Censys organization to associate the request with. | Yes | string | — | No |
| `CENSYS_INSERTED_AFTER_TIME` | RFC3339 timestamp used to seed the initial `inserted_after_time` watermark on the very first run (no prior checkpoint). Must include an explicit `Z` or timezone offset — validated at startup (`utility.validate_rfc3339_env`), raising a `CensysException` (clean HTTP 400) rather than silently accepting a malformed value. Per the endpoint doc's own guidance: start from the time the sync begins, or `1970-01-01T00:00:00Z` for full history. | No | string (RFC3339) | `1970-01-01T00:00:00Z` | No |
| `CENSYS_SEVERITY` | Filter to one or more severities, pipe-separated (`\|`), e.g. `HIGH\|CRITICAL`. Pipe, not comma, is the delimiter — a comma inside the value breaks manual deployment via `gcloud ... --set-env-vars` (see above). Connectors are expected to default to `HIGH\|CRITICAL` for alerting use cases. Accepted: `LOW`, `MEDIUM`, `HIGH`, `CRITICAL`. | No | string | (none — all severities) | No |
| `CENSYS_CHANGE_TYPES` | Filter to one or more change types, pipe-separated (`\|`), e.g. `opened\|resolved\|reopened`. Accepted: `opened`, `resolved`, `reopened`. | No | string | (none — all types) | No |
| `CENSYS_SUPPLIER_NAMES` | Pipe-separated (`\|`) supplier display names, e.g. `Supplier A\|Supplier B`. Each is resolved to a supplier UUID via `GET /v1/supplychains/default/suppliers` and sent as the `supplier_ids` filter. If **every** configured name fails to resolve, the run aborts with a `CensysException` (clean HTTP 400) instead of silently including every supplier; if at least one resolves, the run proceeds scoped to the ones that did, and each invalid name is logged as a `WARNING`. Omit to include every supplier in the supply chain (unless it has more than 1000, in which case this must be set). | No | string | (none — all suppliers) | No |
| `CENSYS_RISK_NAMES` | Pipe-separated (`\|`) risk display names, e.g. `Exposed SMTP Service\|Weak TLS Cipher`. Each is resolved to a `risk_type_id` via `GET /v1/supplychains/default/risks` (paginated catalog scan — no name/keyword search exists on this endpoint) and sent as the `risk_type_ids` filter. If **every** configured name fails to resolve, the run aborts with a `CensysException` (clean HTTP 400) instead of silently including every risk type; if at least one resolves, the run proceeds scoped to the ones that did, and each invalid name is logged as a `WARNING`. Omit to include every risk type. | No | string | (none — all risk types) | No |
| `CENSYS_RAPID_RESPONSE` | Filter to risk events flagged (or not flagged) for rapid response. Omit to include both. Accepted: `true`, `false`. | No | string | (none — both) | No |
| `GCP_BUCKET_NAME` | GCS bucket for checkpoint and process lock state | Yes | string | — | No |
| `CHRONICLE_CUSTOMER_ID` | Google SecOps / Chronicle customer UUID | Yes | string | — | No |
| `CHRONICLE_PROJECT_NUMBER` | GCP project number hosting the Chronicle instance | Yes | string | — | No |
| `CHRONICLE_REGION` | Chronicle region (e.g. `us`, `eu`) | No | string | `us` | No |
| `CHRONICLE_SERVICE_ACCOUNT` | Secret Manager path for Chronicle service account JSON (optional if using ADC) | No | string | — | Yes |

---

## Update Service Account Permissions

To add or change roles on the service account after initial deployment:

```bash
gcloud projects add-iam-policy-binding <PROJECT_ID> \
  --member="serviceAccount:<SA_EMAIL>" \
  --role="roles/storage.admin"
```

---

## Dashboard

### Importing the Dashboard

1. [Log in](https://cloud.google.com/chronicle/docs/log-in-to-ui) to your Google
   SecOps instance.
2. In the navigation bar, click **Dashboards**.
3. Click **New dashboard** and then select **Import from JSON**.
4. Select `Censys - Supplier Risk Overview.json` and click **Confirm**.
5. Click **Import** to continue importing the dashboard to a personal or shared
   dashboard.

### Censys - Supplier Risk Overview

After the connector ingests Censys risk events into Google SecOps, this
dashboard visualizes open/closed risk trends, severity and category breakdowns,
supplier risk ranking, and rapid-response findings.

**1. Filters description** **Timerange** This filter updates the panels based on
the time range selected. Default: Last 1 day.

**Severity** This filter updates the panels based on the severity (`LOW`,
`MEDIUM`, `HIGH`, `CRITICAL`) selected. Default: empty (no filter).

**Risk Category** This filter updates the panels based on the risk category
(e.g. `VULNERABILITY`, `MISCONFIGURATION`, `EXPOSURE`) selected. Default: empty
(no filter).

**Status** This filter updates the panels based on the risk status (`open`,
`closed`) selected. Default: empty (no filter).

**Supplier** This filter updates the panels based on the supplier display name
selected. Default: empty (no filter).

**Risk Instance ID** This filter updates the panels based on the risk instance
ID selected. Default: empty (no filter).

**Risk Name** This filter updates the panels based on the risk name selected.
Default: empty (no filter).

**2. Panels description** **Open Risk Count by Severity** Displays the count of
currently-open risk instances (latest event per `risk_instance_id`), grouped by
severity. Responds to Timerange, Severity, Risk Category, Status, Supplier, Risk
Instance ID, and Risk Name filters. Group by: Severity Visualization type: Pie
Chart

**Top Risk Categories** Displays open risk events ranked by risk category.
Responds to Timerange, Severity, Supplier, Risk Instance ID, and Risk Name
filters. (Always scoped to open risks — the Status filter does not narrow this
panel further, since the underlying query hardcodes `status = "open"`.) Group
by: Risk Category Visualization type: Pie Chart

**Open vs. Closed Risks** Displays the count of open vs. resolved transition
events over the selected time range, as a trend line per status. Responds to
Timerange, Severity, Risk Category, Status, Supplier, Risk Instance ID, and Risk
Name filters. Group by: Time bucket, Status Visualization type: Line Chart

**Supplier Risk Ranking** Displays a tabular list of suppliers ranked by open
risk event count (via `supplier.display_name`), descending. Limited to 100 rows.
Responds to Timerange, Severity, Risk Category, Supplier, Risk Instance ID, and
Risk Name filters. (Always scoped to open risks.) Group by: Supplier
Visualization type: Table

**Top 20 Risks by Open Risk Count** Displays a tabular list of CVE-keyed risk
names ranked by count of open risk events referencing them, descending. Limited
to the top 20 rows. Responds to Timerange, Severity, Risk Category, Supplier,
and Risk Instance ID filters. (Always scoped to open risks.) Clicking a risk
name runs a search on it. Group by: Risk Name Visualization type: Table

**Rapid Response Events** Displays a tabular list of events flagged for rapid
response, including event ID, time, risk name, confidence score, description,
host IP, platform URL, supplier, risk score, and severity. Limited to 100 rows.
Responds to Timerange, Severity, Risk Category, Status, Supplier, Risk Instance
ID, and Risk Name filters. Clicking an event ID runs a search on it. Group by:
Event ID Visualization type: Table

> **Note:** The underlying query for this panel currently filters on
> `security_result.detection_fields["rapid_response"] = "false"`, which appears
> to contradict its name/description (events flagged **for** rapid response).
> Verify whether this is intentional before relying on it, and update the query
> if it should instead filter on `"true"`.

---

## Detection Rules

### Importing the Rule

1. [Log in](https://cloud.google.com/chronicle/docs/log-in-to-ui) to your Google
   SecOps instance.
2. In the navigation bar, click **Rules & Detections**, then **Rules Editor**.
3. Click **New rule** and choose to paste/import YARA-L text.
4. Open `rules/censys_sri_open_high_critical_risk.yaral` and paste its contents
   in, or import the file directly if your instance supports file upload.
5. Click **Save**, then enable the rule so it starts evaluating incoming
   `CENSYS_SUPPLIER_RISK_CUSTOM` events.

> **Note:** The rule **file** is named
> `censys_sri_open_high_critical_risk.yaral` ("sri"), but the rule identifier
> and `rule_name` inside it are `censys_sr_open_high_critical_risk` / "Censys
> SR - Open High/Critical Supplier Risk" ("sr"). This mirrors the product rename
> done elsewhere in this connector (`Supplier Risk Intelligence` →
> `Supplier Risk`) — worth confirming the filename is updated to match before
> this is treated as final, since Google SecOps identifies the rule by its
> internal `rule_name`/identifier, not its filename.

### Censys SR - Open High/Critical Supplier Risk

Generates a detection for a supplier risk instance that is opened or reopened
(currently in `open` status) at `HIGH` or `CRITICAL` severity, correlated by
risk instance ID over a rolling 24-hour window.

**Rule metadata**

| Field | Value |
|-------|-------|
| Rule identifier | `censys_sr_open_high_critical_risk` |
| Display name (`rule_name`) | Censys SR - Open High/Critical Supplier Risk |
| Severity | High |
| Priority | High |
| Product | Censys Supplier Risk |
| Rule version | 1.0 |
| Author | Censys |

**Trigger logic** — all of the following must be true for an event to match:

- `metadata.log_type = "CENSYS_SUPPLIER_RISK_CUSTOM"` — scopes the rule to this
  connector's events only.
- `security_result.detection_fields["status"] = "open"` — the risk instance's
  current status (as of this event) is open, not resolved.
- `security_result.detection_fields["change_type"]` is `"opened"` **or**
  `"reopened"` — the event itself represents a transition into the open state
  (excludes a `resolved` event, even though a resolved instance could
  theoretically still read as high-severity metadata).
- `security_result.severity` is `"CRITICAL"` **or** `"HIGH"` — `MEDIUM`, `LOW`,
  and `UNSPECIFIED` do not trigger this rule.
- `security_result.threat_id` (the risk instance ID) is non-empty — guards
  against correlating on a blank key.

**Grouping / match window**

`$risk_instance_id over 24h` — all matching events for the **same** risk
instance ID within a rolling 24-hour window are correlated into a single
detection, rather than one detection per event.

**Outcome fields**

| Field | Description |
|-------|-------------|
| `risk_score` | `90` if any matched event in the window is `CRITICAL` severity, otherwise `70` (`HIGH`). |
| `total_events` | Count of all matching events for this risk instance within the window. |
| `change_type` | Distinct change types observed in the window (`opened`, `reopened`). |
| `censys_severity` | Distinct severities observed in the window. |
| `risk_name` | Distinct human-readable risk name(s) (`security_result.threat_name`). |
| `risk_type_id` | Distinct Censys/CVE catalog risk type ID(s) (`security_result.rule_id`). |
| `risk_category` | Distinct risk categories (e.g. `VULNERABILITY`, `MISCONFIGURATION`, `EXPOSURE`). |
| `supplier_name` | Distinct impacted supplier display name(s). |
| `supplier_id` | Distinct impacted supplier UUID(s). |
| `target_ip` | Distinct impacted asset IP address(es). |
| `target_hostname` | Distinct impacted asset hostname(s). |
| `platform_url` | Distinct deep link(s) back to the finding in the Censys Platform UI. |

**Condition:** `$event` — a detection is generated once at least one qualifying
event exists for a given `risk_instance_id` within the 24-hour window.

---

## Limitations

- **Single-tenant**: One organization per connector deployment. For multiple
  organizations, deploy one Cloud Function per org.
- **Single supply chain**: Every call targets the organization's `default`
  (primary) supply chain. Organizations with multiple supply chains are not
  supported by this connector as currently scoped.
- **Base URL and page size are not configurable**: the connector always targets
  `https://api.platform.censys.io` at a fixed page size of 1000 (the documented
  maximum).
- **Supplier removal gaps**: The Censys feed does NOT emit transition events
  when a supplier is removed from a supply chain or a supply chain is deleted.

---

## Known Behaviours

- **At-least-once delivery**: Risk events include an `id` field; the CBN parser
  / Google SecOps can deduplicate by this field.
- **`confidence` as float**: The field is preserved as a float (e.g. `0.75`) —
  not truncated to an integer.
- **`severity = UNSPECIFIED`**: Passed through to Chronicle without conversion.
- **`discovery_paths` empty array**: Handled gracefully; included in payload as
  `[]`.
- **503 treated as retryable**: Unlike many APIs, Censys uses 503 for
  request-rate limits. The connector treats it identically to 429 (retryable,
  Retry-After honoured).
- **Process lock**: If Cloud Scheduler fires a second invocation while the first
  is still running, the second exits immediately with HTTP 409. If the lock is
  stale (older than `MAX_EXECUTION_TIME_MINUTES`), it self-recovers.

---

## Troubleshooting

| Symptom | Likely Cause | Resolution |
|---------|-------------|------------|
| `409 - Another process is already running` | Previous invocation is still running or crashed | Check Cloud Function logs; if the previous run finished, wait for the stale-lock timeout (55 min) or manually update `process_running=false` in `censys_checkpoint.json`. |
| Need to force a resync / backfill | Want to re-ingest from an earlier point | Manually edit or delete the `risk_events_inserted_after_time` / `risk_events_inserted_after_event_id` keys in `gs://<bucket>/censys_checkpoint.json`. Clearing both causes the next run to re-seed from `CENSYS_INSERTED_AFTER_TIME`. Downstream dedup on event `id` makes re-ingestion of already-seen events safe. |
| `401 Authentication failed` | Invalid or expired PAT | Rotate the Censys PAT in the Censys UI, update the Secret Manager secret version. |
| `403 Access denied` | Token lacks Supply Chain Intelligence scope | Re-generate the PAT in the Censys Platform UI with the correct scope. |
| `GCS bucket not found` (HTTP 400) | `GCP_BUCKET_NAME` points to a non-existent bucket | Create the bucket or correct the env var. Raised as a dedicated `GCSBucketNotFoundError` (clean HTTP 400), not a generic/unhandled error. |
| Some supplier names not resolving (others do) | Display name mismatch, or ambiguous match, on a subset of names | Check logs for a `WARNING` per unresolved name. The run still proceeds, scoped to the names that did resolve. Check exact spelling in the Censys UI; update `CENSYS_SUPPLIER_NAMES`. |
| `CensysException - none resolved to a supplier ID` | **Every** name in `CENSYS_SUPPLIER_NAMES` failed to resolve | The run aborts rather than silently including every supplier. Check exact spelling in the Censys UI against the `display_name` field; update `CENSYS_SUPPLIER_NAMES`. |
| Some risk names not resolving (others do) | Display name mismatch, or ambiguous match, on a subset of names | Check logs for a `WARNING` per unresolved name. The run still proceeds, scoped to the names that did resolve. Check exact spelling against the `name` field in the Censys risk catalog; update `CENSYS_RISK_NAMES`. |
| `CensysException - none resolved to a risk_type_id` | **Every** name in `CENSYS_RISK_NAMES` failed to resolve | The run aborts rather than silently including every risk type. Check exact spelling against the `name` field in the Censys risk catalog; update `CENSYS_RISK_NAMES`. |

---

## Resources

- [Censys Supply Chain Intelligence API documentation](https://docs.censys.io/docs/supply-chain-risk-intelligence)
- [Google SecOps Chronicle Ingestion API](https://cloud.google.com/chronicle/docs/ingestion/ingestion-api)
- [Google Cloud Functions Gen 2](https://cloud.google.com/functions/docs/2nd-gen/overview)
- [Google Cloud Secret Manager](https://cloud.google.com/secret-manager/docs)
