# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# pylint: disable=line-too-long
# pylint: disable=g-importing-member
# pylint: disable=invalid-name
# pylint: disable=g-multiple-import
# pylint: disable=unused-argument
# pylint: disable=g-import-not-at-top
# pylint: disable=g-bad-import-order
# pylint: disable=missing-class-docstring
# pylint: disable=missing-function-docstring
# pylint: disable=g-bad-exception-name
# pylint: disable=broad-exception-raised

"""Unit tests for exception_handler module."""

import unittest
from unittest.mock import MagicMock, patch
import sys


# --- Mock external dependencies before importing the module under test ---


class MockConnectTimeout(Exception):
  pass


class MockReadTimeout(Exception):
  pass


class MockTooManyRedirects(Exception):
  pass


class MockHTTPError(Exception):
  pass


class MockSSLError(Exception):
  pass


mock_requests = MagicMock()
mock_requests_exceptions = MagicMock()
mock_requests_exceptions.ConnectTimeout = MockConnectTimeout
mock_requests_exceptions.ReadTimeout = MockReadTimeout
mock_requests_exceptions.TooManyRedirects = MockTooManyRedirects
mock_requests_exceptions.HTTPError = MockHTTPError
mock_requests_exceptions.SSLError = MockSSLError
mock_requests.exceptions = mock_requests_exceptions

sys.modules["requests"] = mock_requests
sys.modules["requests.exceptions"] = mock_requests_exceptions
sys.modules["common"] = MagicMock()
sys.modules["common.utils"] = MagicMock()

import exception_handler  # noqa: E402
import constant  # noqa: E402

INGESTION_SCRIPTS_PATH = ""


class TestCensysException(unittest.TestCase):
  """Tests for CensysException."""

  def test_initialization_with_message(self):
    exc = exception_handler.CensysException("API error")
    self.assertEqual(exc.message, "API error")
    self.assertEqual(str(exc), "API error")

  def test_inherits_from_exception(self):
    exc = exception_handler.CensysException("err")
    self.assertIsInstance(exc, Exception)

  def test_can_be_raised_and_caught(self):
    with self.assertRaises(exception_handler.CensysException) as ctx:
      raise exception_handler.CensysException("test error")
    self.assertEqual(ctx.exception.message, "test error")

  def test_empty_message(self):
    exc = exception_handler.CensysException("")
    self.assertEqual(exc.message, "")
    self.assertEqual(str(exc), "")


class TestRunTimeExceeded(unittest.TestCase):
  """Tests for RunTimeExceeded."""

  def test_default_message(self):
    exc = exception_handler.RunTimeExceeded()
    self.assertEqual(exc.message, "Execution time limit exceeded")
    self.assertIn("Execution time limit exceeded", str(exc))

  def test_custom_message(self):
    exc = exception_handler.RunTimeExceeded("Custom timeout")
    self.assertEqual(exc.message, "Custom timeout")
    self.assertIn("Custom timeout", str(exc))

  def test_inherits_from_exception(self):
    exc = exception_handler.RunTimeExceeded()
    self.assertIsInstance(exc, Exception)


class TestGCPPermissionDeniedError(unittest.TestCase):
  """Tests for GCPPermissionDeniedError."""

  def test_basic_initialization(self):
    err = exception_handler.GCPPermissionDeniedError("Access denied")
    self.assertEqual(err.message, "Access denied")
    self.assertIsNone(err.resource)
    self.assertEqual(err.permissions, [])

  def test_initialization_with_resource(self):
    err = exception_handler.GCPPermissionDeniedError(
        "Denied", resource="gs://bucket/file"
    )
    self.assertEqual(err.resource, "gs://bucket/file")

  def test_initialization_with_permissions(self):
    perms = ["Storage Admin", "Secret Manager Secret Accessor"]
    err = exception_handler.GCPPermissionDeniedError("Denied", permissions=perms)
    self.assertEqual(err.permissions, perms)

  def test_initialization_with_all_params(self):
    perms = ["Storage Admin"]
    err = exception_handler.GCPPermissionDeniedError(
        "Denied", resource="gs://b/f", permissions=perms
    )
    self.assertEqual(err.message, "Denied")
    self.assertEqual(err.resource, "gs://b/f")
    self.assertEqual(err.permissions, perms)

  def test_str_representation_message_only(self):
    err = exception_handler.GCPPermissionDeniedError("Access denied")
    self.assertEqual(str(err), "Access denied")

  def test_str_representation_with_resource(self):
    err = exception_handler.GCPPermissionDeniedError(
        "Access denied", resource="gs://bucket/file"
    )
    self.assertIn("for resource: gs://bucket/file", str(err))

  def test_str_representation_with_permissions(self):
    perms = ["Storage Admin", "Viewer"]
    err = exception_handler.GCPPermissionDeniedError(
        "Access denied", permissions=perms
    )
    self.assertIn("Required permissions:", str(err))
    self.assertIn("Storage Admin", str(err))
    self.assertIn("Viewer", str(err))

  def test_str_representation_with_all(self):
    perms = ["Storage Admin"]
    err = exception_handler.GCPPermissionDeniedError(
        "Access denied", resource="gs://b", permissions=perms
    )
    result = str(err)
    self.assertIn("Access denied", result)
    self.assertIn("for resource: gs://b", result)
    self.assertIn("Required permissions: Storage Admin", result)

  def test_permissions_default_to_empty_list(self):
    err = exception_handler.GCPPermissionDeniedError("msg")
    self.assertIsInstance(err.permissions, list)
    self.assertEqual(len(err.permissions), 0)

  def test_inherits_from_exception(self):
    err = exception_handler.GCPPermissionDeniedError("msg")
    self.assertIsInstance(err, Exception)


class TestExceptionHandlerDecorator(unittest.TestCase):
  """Tests for the @exception_handler decorator factory."""

  @patch(f"{INGESTION_SCRIPTS_PATH}exception_handler.utils.cloud_logging")
  def test_successful_function_passthrough(self, mock_logging):
    @exception_handler.exception_handler(action_name="Test API")
    def success_func():
      return {"status": True, "data": "ok"}

    result = success_func()
    self.assertTrue(result["status"])
    self.assertEqual(result["data"], "ok")
    mock_logging.assert_not_called()

  @patch(f"{INGESTION_SCRIPTS_PATH}exception_handler.utils.cloud_logging")
  @patch(
      f"{INGESTION_SCRIPTS_PATH}exception_handler.requests.exceptions.ConnectTimeout",
      MockConnectTimeout,
  )
  def test_connect_timeout_sets_retry(self, mock_logging):
    @exception_handler.exception_handler(action_name="Test API")
    def timeout_func():
      raise MockConnectTimeout("Timeout")

    result = timeout_func()
    self.assertFalse(result["status"])
    self.assertTrue(result["retry"])
    self.assertIn("connection timeout", result["error"].lower())
    mock_logging.assert_called_once()

  @patch(f"{INGESTION_SCRIPTS_PATH}exception_handler.utils.cloud_logging")
  @patch(
      f"{INGESTION_SCRIPTS_PATH}exception_handler.requests.exceptions.ReadTimeout",
      MockReadTimeout,
  )
  def test_read_timeout_sets_retry(self, mock_logging):
    @exception_handler.exception_handler(action_name="Test API")
    def timeout_func():
      raise MockReadTimeout("Read timeout")

    result = timeout_func()
    self.assertFalse(result["status"])
    self.assertTrue(result["retry"])
    self.assertIn("read timeout", result["error"].lower())
    mock_logging.assert_called_once()

  @patch(f"{INGESTION_SCRIPTS_PATH}exception_handler.utils.cloud_logging")
  @patch(
      f"{INGESTION_SCRIPTS_PATH}exception_handler.requests.exceptions.TooManyRedirects",
      MockTooManyRedirects,
  )
  def test_too_many_redirects_no_retry(self, mock_logging):
    @exception_handler.exception_handler(action_name="Test API")
    def redirect_func():
      raise MockTooManyRedirects("Redirects")

    result = redirect_func()
    self.assertFalse(result["status"])
    self.assertFalse(result["retry"])
    self.assertIn("too many redirects", result["error"].lower())
    mock_logging.assert_called_once()

  @patch(f"{INGESTION_SCRIPTS_PATH}exception_handler.utils.cloud_logging")
  @patch(
      f"{INGESTION_SCRIPTS_PATH}exception_handler.requests.exceptions.HTTPError",
      MockHTTPError,
  )
  def test_http_error_no_retry(self, mock_logging):
    @exception_handler.exception_handler(action_name="Test API")
    def http_error_func():
      raise MockHTTPError("HTTP error")

    result = http_error_func()
    self.assertFalse(result["status"])
    self.assertFalse(result["retry"])
    self.assertIn("HTTP error", result["error"])
    mock_logging.assert_called_once()

  @patch(f"{INGESTION_SCRIPTS_PATH}exception_handler.utils.cloud_logging")
  @patch(
      f"{INGESTION_SCRIPTS_PATH}exception_handler.requests.exceptions.SSLError",
      MockSSLError,
  )
  def test_ssl_error_no_retry(self, mock_logging):
    @exception_handler.exception_handler(action_name="Test API")
    def ssl_func():
      raise MockSSLError("SSL")

    result = ssl_func()
    self.assertFalse(result["status"])
    self.assertFalse(result["retry"])
    self.assertIn("SSL error", result["error"])
    mock_logging.assert_called_once()

  @patch(f"{INGESTION_SCRIPTS_PATH}exception_handler.utils.cloud_logging")
  def test_generic_exception_no_retry(self, mock_logging):
    @exception_handler.exception_handler(action_name="Test API")
    def generic_func():
      raise Exception("Generic error")

    result = generic_func()
    self.assertFalse(result["status"])
    self.assertFalse(result["retry"])
    self.assertIn("API call failed", result["error"])
    mock_logging.assert_called_once()

  @patch(f"{INGESTION_SCRIPTS_PATH}exception_handler.utils.cloud_logging")
  def test_decorator_with_arguments(self, mock_logging):
    @exception_handler.exception_handler(action_name="Test API")
    def func_with_args(a, b, kwarg=None):
      return {"status": True, "result": f"{a}-{b}-{kwarg}"}

    result = func_with_args("x", "y", kwarg="z")
    self.assertTrue(result["status"])
    self.assertEqual(result["result"], "x-y-z")

  @patch(f"{INGESTION_SCRIPTS_PATH}exception_handler.utils.cloud_logging")
  def test_error_contains_check_logs_directive(self, mock_logging):
    @exception_handler.exception_handler(action_name="Test API")
    def error_func():
      raise MockConnectTimeout("Timeout")

    result = error_func()
    self.assertIn(constant.CHECK_LOGS_FOR_MORE_DETAILS, result["error"])


if __name__ == "__main__":
  unittest.main()
