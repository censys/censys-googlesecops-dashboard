# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# pylint: disable=line-too-long
# pylint: disable=g-importing-member
# pylint: disable=invalid-name
# pylint: disable=g-multiple-import
# pylint: disable=unused-argument
# pylint: disable=g-import-not-at-top
# pylint: disable=g-bad-import-order
# pylint: disable=missing-class-docstring
# pylint: disable=missing-function-docstring
# pylint: disable=g-bad-exception-name

"""Unit tests for the main module."""

import sys
import unittest
from unittest.mock import MagicMock, Mock, patch

# --- Bootstrap all external dependencies before any project imports ---

mock_common = MagicMock()
mock_utils = MagicMock()
mock_common.utils = mock_utils

sys.modules["common"] = mock_common
sys.modules["common.utils"] = mock_utils
sys.modules["common.ingest_v1"] = MagicMock()
sys.modules["common.env_constants"] = MagicMock()

sys.modules["google"] = MagicMock()
sys.modules["google.cloud"] = MagicMock()
sys.modules["google.cloud.storage"] = MagicMock()
sys.modules["google.cloud.exceptions"] = MagicMock()
sys.modules["google.cloud.resourcemanager_v3"] = MagicMock()

mock_requests = MagicMock()
sys.modules["requests"] = mock_requests

from exception_handler import (  # noqa: E402
    CensysException,
    GCPPermissionDeniedError,
    GCSBucketNotFoundError,
    RunTimeExceeded,
)
import main  # noqa: E402

INGESTION_SCRIPTS_PATH = ""


class TestMainHappyPath(unittest.TestCase):
  """Tests for the successful execution path."""

  @patch(f"{INGESTION_SCRIPTS_PATH}main.censys_client.CensysClient")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.release_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.acquire_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.validate_rfc3339_env")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_successful_execution_returns_200(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_validate_rfc3339,
      mock_acquire_lock,
      mock_release_lock,
      mock_client_cls,
  ):
    mock_check_perms.return_value = True
    mock_get_env.side_effect = [
        "my-bucket",                        # GCP_BUCKET_NAME
        "tok-secret",                       # CENSYS_API_KEY
        "org-uuid",                         # CENSYS_ORGANIZATION_ID
        "",                                 # CENSYS_SUPPLIER_NAMES
        "",                                 # CENSYS_RISK_NAMES
        "1970-01-01T00:00:00Z",             # CENSYS_INSERTED_AFTER_TIME
    ]
    mock_validate_rfc3339.return_value = "1970-01-01T00:00:00Z"
    mock_acquire_lock.return_value = True

    mock_client = Mock()
    mock_client_cls.return_value = mock_client
    mock_client.fetch_risk_events.return_value = None

    result, status_code = main.main(None)

    self.assertEqual(status_code, 200)
    self.assertIn("success", result.lower())
    mock_client.fetch_risk_events.assert_called_once()
    mock_release_lock.assert_called_once_with("my-bucket")

  @patch(f"{INGESTION_SCRIPTS_PATH}main.censys_client.CensysClient")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.release_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.acquire_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.validate_rfc3339_env")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_client_instantiated_with_correct_params(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_validate_rfc3339,
      mock_acquire_lock,
      mock_release_lock,
      mock_client_cls,
  ):
    mock_check_perms.return_value = True
    mock_get_env.side_effect = [
        "my-bucket",
        "the-token",
        "org-uuid",
        "Supplier A",
        "Risk A",
        "2020-01-01T00:00:00Z",
    ]
    mock_validate_rfc3339.return_value = "2020-01-01T00:00:00Z"
    mock_acquire_lock.return_value = True
    mock_client = Mock()
    mock_client_cls.return_value = mock_client

    main.main(None)

    mock_client_cls.assert_called_once_with(
        access_token="the-token",
        organization_id="org-uuid",
        supplier_names="Supplier A",
        risk_names="Risk A",
        inserted_after_time="2020-01-01T00:00:00Z",
        bucket_name="my-bucket",
    )


class TestMainLockHandling(unittest.TestCase):
  """Tests for process lock behaviour."""

  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.acquire_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_returns_409_when_lock_is_busy(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_acquire_lock,
  ):
    mock_check_perms.return_value = True
    mock_get_env.side_effect = ["my-bucket"]
    mock_acquire_lock.return_value = False

    result, status_code = main.main(None)

    self.assertEqual(status_code, 409)
    self.assertIn("already running", result)

  @patch(f"{INGESTION_SCRIPTS_PATH}main.censys_client.CensysClient")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.release_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.acquire_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.validate_rfc3339_env")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_lock_released_on_success(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_validate_rfc3339,
      mock_acquire_lock,
      mock_release_lock,
      mock_client_cls,
  ):
    mock_check_perms.return_value = True
    mock_get_env.side_effect = [
        "my-bucket",
        "tok",
        "org",
        "",
        "",
        "1970-01-01T00:00:00Z",
    ]
    mock_validate_rfc3339.return_value = "1970-01-01T00:00:00Z"
    mock_acquire_lock.return_value = True
    mock_client = Mock()
    mock_client_cls.return_value = mock_client

    main.main(None)

    mock_release_lock.assert_called_once_with("my-bucket")

  @patch(f"{INGESTION_SCRIPTS_PATH}main.censys_client.CensysClient")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.release_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.acquire_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.validate_rfc3339_env")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_lock_released_on_censys_exception(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_validate_rfc3339,
      mock_acquire_lock,
      mock_release_lock,
      mock_client_cls,
  ):
    mock_check_perms.return_value = True
    mock_get_env.side_effect = [
        "my-bucket",
        "tok",
        "org",
        "",
        "",
        "1970-01-01T00:00:00Z",
    ]
    mock_validate_rfc3339.return_value = "1970-01-01T00:00:00Z"
    mock_acquire_lock.return_value = True
    mock_client = Mock()
    mock_client_cls.return_value = mock_client
    mock_client.fetch_risk_events.side_effect = CensysException("API error")

    _, status_code = main.main(None)

    self.assertEqual(status_code, 400)
    mock_release_lock.assert_called_once_with("my-bucket")

  @patch(f"{INGESTION_SCRIPTS_PATH}main.censys_client.CensysClient")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.release_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.acquire_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.validate_rfc3339_env")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_lock_released_on_unknown_exception(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_validate_rfc3339,
      mock_acquire_lock,
      mock_release_lock,
      mock_client_cls,
  ):
    mock_check_perms.return_value = True
    mock_get_env.side_effect = [
        "my-bucket",
        "tok",
        "org",
        "",
        "",
        "1970-01-01T00:00:00Z",
    ]
    mock_validate_rfc3339.return_value = "1970-01-01T00:00:00Z"
    mock_acquire_lock.return_value = True
    mock_client = Mock()
    mock_client_cls.return_value = mock_client
    mock_client.fetch_risk_events.side_effect = ValueError("Unexpected")

    _, status_code = main.main(None)

    self.assertEqual(status_code, 500)
    mock_release_lock.assert_called_once_with("my-bucket")


class TestMainExceptionPaths(unittest.TestCase):
  """Tests for exception-to-HTTP-status-code mapping."""

  @patch(f"{INGESTION_SCRIPTS_PATH}main.censys_client.CensysClient")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.release_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.acquire_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.validate_rfc3339_env")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_runtime_exceeded_returns_200(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_validate_rfc3339,
      mock_acquire_lock,
      mock_release_lock,
      mock_client_cls,
  ):
    mock_check_perms.return_value = True
    mock_get_env.side_effect = [
        "my-bucket",
        "tok",
        "org",
        "",
        "",
        "1970-01-01T00:00:00Z",
    ]
    mock_validate_rfc3339.return_value = "1970-01-01T00:00:00Z"
    mock_acquire_lock.return_value = True
    mock_client = Mock()
    mock_client_cls.return_value = mock_client
    mock_client.fetch_risk_events.side_effect = RunTimeExceeded("Time up")

    result, status_code = main.main(None)

    self.assertEqual(status_code, 200)
    self.assertIn("Execution time limit exceeded", result)
    mock_release_lock.assert_called_once_with("my-bucket")

  @patch(f"{INGESTION_SCRIPTS_PATH}main.censys_client.CensysClient")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.release_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.acquire_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.validate_rfc3339_env")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_censys_exception_returns_400(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_validate_rfc3339,
      mock_acquire_lock,
      mock_release_lock,
      mock_client_cls,
  ):
    mock_check_perms.return_value = True
    mock_get_env.side_effect = [
        "my-bucket",
        "tok",
        "org",
        "",
        "",
        "1970-01-01T00:00:00Z",
    ]
    mock_validate_rfc3339.return_value = "1970-01-01T00:00:00Z"
    mock_acquire_lock.return_value = True
    mock_client = Mock()
    mock_client_cls.return_value = mock_client
    mock_client.fetch_risk_events.side_effect = CensysException("API error")

    result, status_code = main.main(None)

    self.assertEqual(status_code, 400)
    self.assertIn("Censys data ingestion", result)

  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_gcp_permission_denied_before_bucket_returns_403(
      self,
      mock_log,
      mock_check_perms,
  ):
    mock_check_perms.side_effect = GCPPermissionDeniedError(
        "Permission denied",
        resource="gs://bucket",
        permissions=["Storage Admin"],
    )

    result, status_code = main.main(None)

    self.assertEqual(status_code, 403)
    self.assertIn("permission", result.lower())

  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.release_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.acquire_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_gcp_permission_denied_after_bucket_releases_lock(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_acquire_lock,
      mock_release_lock,
  ):
    mock_check_perms.return_value = True
    mock_get_env.side_effect = [
        "my-bucket",
    ]
    mock_acquire_lock.side_effect = GCPPermissionDeniedError(
        "Permission denied",
        resource="gs://bucket",
        permissions=["Storage Admin"],
    )

    _, status_code = main.main(None)

    self.assertEqual(status_code, 403)
    mock_release_lock.assert_called_once_with("my-bucket")

  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.release_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.acquire_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_gcs_bucket_not_found_returns_400(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_acquire_lock,
      mock_release_lock,
  ):
    # GCSBucketNotFoundError subclasses RuntimeError, so this specifically
    # guards against it falling through to the generic
    # "unexpected initialization error" (500) handling instead of its own
    # dedicated, clean 400 response.
    mock_check_perms.return_value = True
    mock_get_env.side_effect = [
        "nonexistent-bucket",
    ]
    mock_acquire_lock.side_effect = GCSBucketNotFoundError("nonexistent-bucket")

    result, status_code = main.main(None)

    self.assertEqual(status_code, 400)
    self.assertIn("nonexistent-bucket", result)
    self.assertIn("GCS bucket not found", result)
    mock_release_lock.assert_called_once_with("nonexistent-bucket")

  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.release_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_initialization_error_returns_500(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_release_lock,
  ):
    mock_check_perms.return_value = True
    mock_get_env.side_effect = [
        "my-bucket",
        RuntimeError("Env load error"),
    ]

    result, status_code = main.main(None)

    self.assertEqual(status_code, 500)
    self.assertIn("Error initializing", result)
    mock_release_lock.assert_called_once_with("my-bucket")

  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_permission_check_called_first(
      self,
      mock_log,
      mock_check_perms,
  ):
    mock_check_perms.side_effect = GCPPermissionDeniedError("Denied")

    _, status_code = main.main(None)

    self.assertEqual(status_code, 403)
    mock_check_perms.assert_called_once()


class TestMainConfigurationLogging(unittest.TestCase):
  """Tests for configuration logging."""

  @patch(f"{INGESTION_SCRIPTS_PATH}main.censys_client.CensysClient")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.release_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.acquire_process_lock")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.validate_rfc3339_env")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.get_environment_variable")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utility.check_sufficient_permissions_on_service_account")
  @patch(f"{INGESTION_SCRIPTS_PATH}main.utils.cloud_logging")
  def test_configuration_is_logged(
      self,
      mock_log,
      mock_check_perms,
      mock_get_env,
      mock_validate_rfc3339,
      mock_acquire_lock,
      mock_release_lock,
      mock_client_cls,
  ):
    mock_check_perms.return_value = True
    mock_get_env.side_effect = [
        "my-bucket",
        "tok",
        "org-uuid",
        "Supplier A",
        "",
        "1970-01-01T00:00:00Z",
    ]
    mock_validate_rfc3339.return_value = "1970-01-01T00:00:00Z"
    mock_acquire_lock.return_value = True
    mock_client = Mock()
    mock_client_cls.return_value = mock_client

    main.main(None)

    all_log_messages = " ".join(
        str(call_args[0][0]) for call_args in mock_log.call_args_list
    )
    self.assertIn("Configuration loaded", all_log_messages)


if __name__ == "__main__":
  unittest.main()
