# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Censys Supplier Risk API client."""

import datetime
import json
import platform
import re
import time
import traceback
from typing import Any, Optional

from common import ingest_v1
from common import utils
import constant
import exception_handler
from google.cloud import storage as gcs_storage
import requests
import utility

# Matches the fractional-seconds portion of an RFC3339 timestamp (e.g. the
# ".279725054" in "2026-08-11T00:26:33.279725054+00:00"), which the API may
# return with anywhere from 0 to 9 digits. Used to truncate to microsecond
# precision before parsing with datetime.fromisoformat(), which (pre-3.11)
# only accepts exactly 3 or 6 fractional digits.
_FRACTIONAL_SECONDS_RE = re.compile(r"(\.\d+)(?=[+-])")


class CensysClient:
  """A client for interacting with the Censys Supplier Risk API.

  This client handles:
  - Bearer token authentication via Personal Access Token (PAT).
  - Checkpointing via inserted_after_time / inserted_after_event_id (the
    documented cross-run cursor), with page_token used only to paginate
    within a single run.
  - Optional supplier name resolution (matching display names to UUIDs)
    against the organization's default (primary) supply chain.
  - Optional risk name resolution (matching display names to risk_type_ids)
    against the same supply chain's risk catalog.
  - Server-side filters: change_types, severity, risk_type_ids,
    rapid_response, supplier_ids.
  - Retry logic with Retry-After header support for 429/503 responses.
  - HTTP 410 detection (cursor expired — operator intervention required).
  - Chronicle ingestion via ingest_v1.ingest().
  - Checkpoint management (watermark persisted to GCS after each
    successfully ingested page).
  """

  def __init__(
      self,
      access_token: str,
      organization_id: str,
      supplier_names: str,
      risk_names: str,
      inserted_after_time: Optional[str],
      bucket_name: str,
  ) -> None:
    """Initialize CensysClient with required configuration.

    Args:
        access_token: Personal Access Token for Bearer auth.
        organization_id: Organization UUID required on every API call.
        supplier_names: Pipe-separated ('|') supplier display names for
            filtering (empty string means no filtering).
        risk_names: Pipe-separated ('|') risk display names for filtering
            (empty string means no filtering), resolved to risk_type_ids.
        inserted_after_time: Already-validated RFC3339 timestamp used to
            seed the watermark on the very first run (no prior checkpoint).
        bucket_name: GCS bucket name for checkpoint state.
    """
    self.base_url = constant.CENSYS_API_BASE_URL.rstrip("/")
    self.access_token = access_token
    self.organization_id = organization_id
    self.supplier_names = supplier_names
    self.risk_names = risk_names
    self.inserted_after_time = inserted_after_time
    self.bucket_name = bucket_name

  def _build_auth_headers(self) -> dict[str, str]:
    """Build the Authorization and User-Agent headers for Bearer token auth.

    The User-Agent is rebuilt on every call (rather than read from a static
    constant) so its ts= value reflects the time of that specific request.

    Returns:
        A dict containing the Authorization and User-Agent headers.
    """
    user_agent = constant.USER_AGENT_TEMPLATE.format(
        version=constant.INTEGRATION_VERSION,
        python_version=platform.python_version(),
        epoch_time=int(time.time()),
    )
    return {
        "Authorization": f"Bearer {self.access_token}",
        "User-Agent": user_agent,
    }

  @exception_handler.exception_handler(action_name="Censys REST API")
  def _censys_rest_api(
      self,
      method: str,
      url: str,
      params: dict[str, Any],
  ) -> dict[str, Any]:
    """Make a raw HTTP call to the Censys API.

    This method is decorated with @exception_handler so network exceptions
    are caught and returned as error dicts instead of being raised. The
    caller (make_api_call) reads the dict to decide whether to retry.

    Args:
        method: HTTP method (e.g. "GET").
        url: Full URL to call.
        params: Query parameters to include in the request.

    Returns:
        A dict with keys 'response' (requests.Response), 'status' (True),
        and 'retry' (False) on success. On exception, the @exception_handler
        decorator returns a dict with 'status' False and 'retry' set
        according to the exception type.
    """
    response = requests.request(
        method=method,
        url=url,
        headers=self._build_auth_headers(),
        params=params,
        timeout=(constant.CONNECTION_TIMEOUT, constant.READ_TIMEOUT),
        verify=True,
    )
    # response.url is the fully-resolved URL (base + percent-encoded query
    # string) that was actually sent — safe to log as-is since the PAT
    # travels via the Authorization header, never as part of the URL/params.
    utils.cloud_logging(
        f"Censys API call invoked: {method} {response.url}",
        severity="DEBUG",
    )
    return {"response": response, "status": True, "retry": False}

  def _parse_and_handle_response(
      self,
      return_dict: dict[str, Any],
      result: dict[str, Any],
      fetch_type: str,
  ) -> dict[str, Any]:
    """Parse an API response and map status codes to retry decisions.

    Handles:
    - 200: success — parses JSON and sets status=True.
    - 401/403: terminal auth/permission error — raises CensysException.
    - 410: cursor expired — raises CensysException with operator message.
    - 429/503: rate limit — sets retry=True; caller honours Retry-After.
    - 5xx (other): transient server error — sets retry=True.
    - Other 4xx: terminal client error — sets status=False, no retry.

    Args:
        return_dict: Accumulator dict to populate with parsed result.
        result: Raw dict returned by _censys_rest_api (contains 'response').
        fetch_type: Human-readable label for logging (e.g. "risk events").

    Returns:
        The updated return_dict.

    Raises:
        CensysException: For 401, 403, 410, or non-JSON 200 responses.
    """
    try:
      response = result["response"]
      return_dict["response"] = response
      status_code = response.status_code

      if status_code == 200:
        try:
          return_dict["data"] = response.json()
          return_dict["status"] = True
        except ValueError as exc:
          utils.cloud_logging(
              f"Failed to parse JSON response for {fetch_type}. "
              f"Raw text (first 500 chars): {response.text[:500]}\n"
              f"Traceback: {traceback.format_exc()}",
              severity="ERROR",
          )
          raise exception_handler.CensysException(
              f"Non-JSON response received for {fetch_type}: "
              f"{response.text[:500]}"
          ) from exc

      elif status_code == 401:
        msg = (
            f"Authentication failed for {fetch_type}. "
            "Verify CENSYS_API_KEY."
        )
        utils.cloud_logging(
            f"Failed to fetch {fetch_type}, received status code 401. "
            f"Response: {response.text[:500]}",
            severity="ERROR",
        )
        raise exception_handler.CensysException(msg)

      elif status_code == 403:
        msg = f"Access denied for {fetch_type}. Check token scopes."
        utils.cloud_logging(
            f"Failed to fetch {fetch_type}, received status code 403. "
            f"Response: {response.text[:500]}",
            severity="ERROR",
        )
        raise exception_handler.CensysException(msg)

      elif status_code == 410:
        # Cursor has expired (older than 30 days). Operator intervention needed.
        msg = (
            "Censys risk-events cursor has expired (HTTP 410). The stored "
            "page_token predates the 30-day event retention window. Manual "
            "resync from /v1/risk-instances is required. The checkpoint has "
            "NOT been reset — operator must clear it manually."
        )
        utils.cloud_logging(msg, severity="ERROR")
        raise exception_handler.CensysException(msg)

      elif status_code == 429 or status_code == 503:
        # Both 429 (concurrency limit) and 503 (request-rate limit) are
        # retryable per the Censys API documentation. Both carry Retry-After.
        return_dict["status"] = False
        return_dict["retry"] = True
        return_dict["retry_after"] = self._parse_retry_after(response)
        return_dict["error"] = (
            f"Rate limit / server overload for {fetch_type} "
            f"(status {status_code})."
        )
        utils.cloud_logging(
            f"Received status {status_code} for {fetch_type}. "
            f"Will retry after {return_dict['retry_after']}s.",
            severity="WARNING",
        )

      elif status_code >= 500:
        return_dict["status"] = False
        return_dict["retry"] = True
        return_dict["error"] = (
            f"Server error ({status_code}) while fetching {fetch_type}."
        )
        utils.cloud_logging(
            f"Failed to fetch {fetch_type}, received status code "
            f"{status_code}. Response: {response.text[:500]}",
            severity="ERROR",
        )

      else:
        # Other 4xx — non-retryable client error
        return_dict["status"] = False
        return_dict["error"] = (
            f"Failed to fetch {fetch_type}, status code: {status_code}"
        )
        utils.cloud_logging(
            f"Failed to fetch {fetch_type}, received status code "
            f"{status_code}. Response: {response.text[:500]}",
            severity="ERROR",
        )

    except exception_handler.CensysException:
      raise

    except Exception as ex:  # pylint: disable=broad-except
      response = result.get("response")
      utils.cloud_logging(
          f"Error handling response for {fetch_type}. "
          f"Response: {response.text[:500] if response else 'N/A'}. "
          f"Error: {repr(ex)}\nTraceback: {traceback.format_exc()}",
          severity="ERROR",
      )
    return return_dict

  def _parse_retry_after(self, response: requests.Response) -> int:
    """Parse the Retry-After header from a response.

    Tries to read Retry-After as an integer (seconds). Falls back to
    DEFAULT_SLEEP_TIME if the header is absent or unparseable. Clamps
    the value to MAX_RETRY_AFTER_SECONDS.

    Args:
        response: The HTTP response containing the Retry-After header.

    Returns:
        Number of seconds to wait before retrying.
    """
    retry_after_raw = response.headers.get("Retry-After")
    if retry_after_raw:
      try:
        delay = int(retry_after_raw)
        return min(delay, constant.MAX_RETRY_AFTER_SECONDS)
      except (ValueError, TypeError):
        pass
    return constant.DEFAULT_SLEEP_TIME

  def _log_and_sleep_before_retry(
      self, sleep_time: int = constant.DEFAULT_SLEEP_TIME
  ) -> None:
    """Log a retry message and sleep before the next attempt.

    Args:
        sleep_time: Seconds to sleep.
    """
    utils.cloud_logging(constant.RETRY_MESSAGE.format(delay=sleep_time))
    time.sleep(sleep_time)

  def make_api_call(
      self,
      method: str,
      url: str,
      params: dict[str, Any],
      fetch_type: str = "Censys API",
  ) -> dict[str, Any]:
    """Make a Censys REST API call with retry/backoff logic.

    Retries up to RETRY_COUNT times on transient errors (429, 503, 5xx,
    ConnectTimeout, ReadTimeout). Raises CensysException for terminal
    errors (401, 403, 410).

    Args:
        method: HTTP method (e.g. "GET").
        url: Full URL to call.
        params: Query parameters (organization_id is always included).
        fetch_type: Human-readable label for logging.

    Returns:
        A dict with keys: 'status' (bool), 'data' (dict), 'error' (str),
        'retry' (bool), 'response' (requests.Response | None).
    """
    return_dict = {
        "status": False,
        "data": {},
        "error": "",
        "retry": False,
        "response": None,
    }
    count = 0
    result: dict[str, Any] = {}

    while count < constant.RETRY_COUNT:
      result = self._censys_rest_api(method, url, params)

      # @exception_handler returned an error dict (network exception)
      if not result.get("status") and result.get("retry") is not None:
        if result.get("retry"):
          count += 1
          if count == constant.RETRY_COUNT:
            return_dict.update(result)
            return return_dict
          self._log_and_sleep_before_retry()
          continue
        # Non-retryable network exception
        return result

      # Parse the HTTP response
      result = self._parse_and_handle_response(return_dict, result, fetch_type)

      if result["status"]:
        return result

      if not result.get("retry", False):
        return result

      # Retryable HTTP status — use Retry-After if present
      sleep_time = result.get("retry_after", constant.DEFAULT_SLEEP_TIME)
      count += 1
      if count == constant.RETRY_COUNT:
        break
      self._log_and_sleep_before_retry(sleep_time)

    return_dict.update(result)
    return return_dict

  def _validate_enum_filter(
      self,
      env_name: str,
      tokens: list[str],
      allowed_values: frozenset[str],
  ) -> None:
    """Validate a filter's parsed values against its allowed enum.

    Raises rather than silently passing an invalid value through to the API
    (which would only surface as an opaque 400 deep inside the pagination
    loop) or silently dropping it (which would mask an operator's typo
    behind a filter that quietly stopped applying). Called before any API
    request is made for the run, so an invalid value causes a clean,
    immediate failure.

    Args:
        env_name: The environment variable name, for the error message.
        tokens: Already-split, already-cased values to check.
        allowed_values: The set of valid values, same casing convention as
            tokens.

    Raises:
        CensysException: If any token is not in allowed_values.
    """
    invalid = [v for v in tokens if v not in allowed_values]
    if invalid:
      raise exception_handler.CensysException(
          f"{env_name} contains invalid value(s) {invalid}. Allowed values: "
          f"{sorted(allowed_values)}."
      )

  def _build_base_filter_params(self) -> dict[str, Any]:
    """Build the filter query params that stay constant across a run's pages.

    Per the endpoint doc: "When paginating, provide the same filters, ...
    inserted_after_time and inserted_after_event_id as the request that
    returned the token." So these are computed once per run and reused for
    every page; only page_token changes page to page.

    Reads CENSYS_SEVERITY, CENSYS_CHANGE_TYPES, and CENSYS_RAPID_RESPONSE
    directly from the environment. CENSYS_SEVERITY and CENSYS_CHANGE_TYPES
    accept multiple pipe-separated ('|') values — pipe, not comma, because
    a comma inside an env var's value breaks `gcloud ... --set-env-vars`
    (it also uses comma to separate different KEY=VALUE pairs). The parsed
    values are re-joined with a comma before being sent as the outgoing API
    query param, since that is the wire format the Censys API itself
    expects. Duplicate values (e.g. "HIGH|HIGH|CRITICAL") are deduplicated
    (order-preserving) before validation/joining, so a repeated value is
    sent to the API only once. The three enum-constrained filters
    (severity, change_types, rapid_response) are validated against their
    allowed values — see _validate_enum_filter(). risk_type_ids is NOT
    built here — it is resolved from CENSYS_RISK_NAMES by
    _resolve_risk_type_ids() and layered in by the caller, the same way
    supplier_ids is.

    Returns:
        Dict of query params to send on every page of this run (excluding
        organization_id's sibling pagination params page_token/page_size/
        supplier_ids/risk_type_ids/inserted_after_time/
        inserted_after_event_id, which are layered in by the caller).

    Raises:
        CensysException: If CENSYS_SEVERITY, CENSYS_CHANGE_TYPES, or
            CENSYS_RAPID_RESPONSE contains a value outside its allowed set.
    """
    params: dict[str, Any] = {"organization_id": self.organization_id}

    change_types = utility.get_environment_variable(constant.ENV_CHANGE_TYPES)
    if change_types:
      # Deduplicated (order-preserving) so a repeated value (e.g.
      # "opened|opened") is sent to the API only once.
      change_type_tokens = list(dict.fromkeys(
          v.strip().lower() for v in change_types.split("|") if v.strip()
      ))
      self._validate_enum_filter(
          constant.ENV_CHANGE_TYPES,
          change_type_tokens,
          constant.ALLOWED_CHANGE_TYPES,
      )
      params["change_types"] = ",".join(change_type_tokens)

    severity = utility.get_environment_variable(constant.ENV_SEVERITY)
    if severity:
      # Deduplicated (order-preserving) so a repeated value (e.g.
      # "HIGH|HIGH") is sent to the API only once.
      severity_tokens = list(dict.fromkeys(
          v.strip().upper() for v in severity.split("|") if v.strip()
      ))
      self._validate_enum_filter(
          constant.ENV_SEVERITY,
          severity_tokens,
          constant.ALLOWED_SEVERITY_VALUES,
      )
      params["severity"] = ",".join(severity_tokens)

    rapid_response = utility.get_environment_variable(
        constant.ENV_RAPID_RESPONSE
    )
    if rapid_response:
      normalized_rapid_response = rapid_response.strip().lower()
      self._validate_enum_filter(
          constant.ENV_RAPID_RESPONSE,
          [normalized_rapid_response],
          constant.ALLOWED_RAPID_RESPONSE_VALUES,
      )
      params["rapid_response"] = normalized_rapid_response

    return params

  def _parse_rfc3339(self, value: str) -> datetime.datetime:
    """Parse an RFC3339 timestamp of arbitrary fractional-second precision.

    The API returns inserted_at/occurred_at with anywhere from 0 to 9
    fractional digits (e.g. '...154513Z' vs '...279725054Z'). This
    truncates to microsecond precision (6 digits) so
    datetime.fromisoformat() accepts it on all supported Python versions.

    Args:
        value: An RFC3339 timestamp string, 'Z'-suffixed or with an explicit
            offset.

    Returns:
        A timezone-aware datetime.datetime.
    """
    v = value.strip()
    if v.endswith(("Z", "z")):
      v = v[:-1] + "+00:00"
    v = _FRACTIONAL_SECONDS_RE.sub(
        lambda m: "." + (m.group(1)[1:] + "000000")[:6], v, count=1
    )
    return datetime.datetime.fromisoformat(v)

  def _is_later(
      self,
      time_a: Optional[str],
      id_a: Optional[str],
      time_b: Optional[str],
      id_b: Optional[str],
  ) -> bool:
    """Return True if (time_a, id_a) is strictly later than (time_b, id_b).

    Mirrors the endpoint doc's own tie-break rule: "Of the events inserted
    at exactly inserted_after_time, only those whose id sorts after this
    one are returned" — so on an exact inserted_at tie, id is compared as a
    plain string. Censys event ids are canonical lowercase UUID strings, for
    which lexicographic order is the same as UUID (128-bit) order, so this
    matches the API's ordering. Ties are rare: inserted_at has microsecond
    precision.

    Args:
        time_a: Candidate inserted_at.
        id_a: Candidate event id.
        time_b: Current watermark inserted_at (may be None).
        id_b: Current watermark event id (may be None).

    Returns:
        True if (time_a, id_a) should replace (time_b, id_b) as the
        watermark.
    """
    if not time_a:
      return False
    if not time_b:
      return True
    dt_a = self._parse_rfc3339(time_a)
    dt_b = self._parse_rfc3339(time_b)
    if dt_a != dt_b:
      return dt_a > dt_b
    return (id_a or "") > (id_b or "")

  def _get_risk_events_page(
      self,
      base_params: dict[str, Any],
      page_token: Optional[str],
      supplier_ids: list[str],
      risk_type_ids: list[str],
      page_size: int,
  ) -> dict[str, Any]:
    """Fetch a single page from GET .../supplychains/default/risk-events.

    Within a run, every page is requested against the organization's default
    (primary) supply chain, with the same base_params (filters +
    inserted_after_time/inserted_after_event_id) — only page_token advances.

    Args:
        base_params: Filters plus inserted_after_time/inserted_after_event_id
            for this run, built once by the caller and held constant across
            every page.
        page_token: Opaque cursor from the previous page (None on first page
            of a run).
        supplier_ids: List of supplier UUIDs to filter by (empty = no filter,
            meaning every supplier in the supply chain is included).
        risk_type_ids: List of risk_type_id strings to filter by, resolved
            from CENSYS_RISK_NAMES (empty = no filter, meaning every risk
            type is included).
        page_size: Number of records per page.

    Returns:
        The parsed ``result`` dict from the API response.

    Raises:
        CensysException: If the API returns an error.
    """
    url = f"{self.base_url}{constant.RISK_EVENTS_ENDPOINT}"
    params: dict[str, Any] = dict(base_params)
    params["page_size"] = page_size
    if page_token:
      params["page_token"] = page_token
    if supplier_ids:
      # Censys API accepts repeated query params for array fields; pass as
      # comma-joined string which the API also accepts for supplier_ids.
      params["supplier_ids"] = ",".join(supplier_ids)
    if risk_type_ids:
      params["risk_type_ids"] = ",".join(risk_type_ids)

    response = self.make_api_call(
        "GET", url, params=params, fetch_type="risk events"
    )

    if not response.get("status"):
      raise exception_handler.CensysException(
          f"Error fetching risk events page: {response.get('error')}"
      )

    data = response.get("data", {})
    result = data.get("result", {})
    return result

  def _load_supplier_cache(self) -> dict[str, Any]:
    """Read the supplier name cache from GCS.

    The cache maps supplier display names to their resolved UUIDs.
    Returns an empty dict if the cache file does not exist.

    Returns:
        Dict of the form {'SupplierName': {'supplier_id': '<uuid>',
        'resolved_at': '<iso_timestamp>'}, ...}.
    """
    try:
      storage_client = gcs_storage.Client()
      bucket = storage_client.get_bucket(self.bucket_name)
      blob = bucket.blob(constant.SUPPLIER_CACHE_FILE)
      if blob.exists():
        cache = json.loads(
            blob.download_as_text(timeout=constant.BLOB_DOWNLOAD_TIMEOUT)
        )
        utils.cloud_logging(
            f"Loaded supplier name cache with {len(cache)} entries.",
            severity="DEBUG",
        )
        return cache
    except Exception as e:  # pylint: disable=broad-except
      utils.cloud_logging(
          f"Could not load supplier name cache: {repr(e)}\n"
          f"Traceback: {traceback.format_exc()}",
          severity="WARNING",
      )
    return {}

  def _save_supplier_cache(self, cache: dict[str, Any]) -> None:
    """Write the supplier name cache to GCS.

    Args:
        cache: Resolved supplier name cache dict to persist.
    """
    try:
      storage_client = gcs_storage.Client()
      bucket = storage_client.get_bucket(self.bucket_name)
      blob = bucket.blob(constant.SUPPLIER_CACHE_FILE)
      blob.upload_from_string(
          json.dumps(cache),
          content_type="application/json",
          timeout=30,
      )
      utils.cloud_logging(
          f"Saved supplier name cache with {len(cache)} entries.",
          severity="DEBUG",
      )
    except Exception as e:  # pylint: disable=broad-except
      utils.cloud_logging(
          f"Could not save supplier name cache: {repr(e)}\n"
          f"Traceback: {traceback.format_exc()}",
          severity="WARNING",
      )

  def _resolve_supplier_ids(self) -> list[str]:
    """Resolve supplier display names to supplier UUIDs.

    Resolution logic:
    1. Call GET /v1/supplychains/default/suppliers, paginating through the
       full supplier list via _list_all_suppliers() — this endpoint has no
       name/keyword search parameter, so every supplier must be fetched to
       find a match. "default" resolves server-side to the organization's
       primary supply chain, so no separate list-supply-chains call is
       made to discover its real ID.
    2. Match each configured name against supplier.display_name.
    3. Names with zero or more-than-one match are skipped with a WARNING.
       If at least one configured name resolves, the run proceeds scoped
       to whatever did resolve. If every configured name fails to resolve
       (and the suppliers list was fetched successfully), a
       CensysException is raised instead of silently falling back to "no
       supplier filter" (which would otherwise widen an intentionally
       scoped run to every supplier in the supply chain).

    Duplicate names in CENSYS_SUPPLIER_NAMES (e.g. "Supplier A|Supplier A")
    are deduplicated before resolution, so a repeated name contributes its
    resolved ID to the output only once.

    Cache: persisted to censys_supplier_name_cache.json. A cache hit is
    used directly to avoid repeat API calls. The cache does NOT affect the
    event cursor checkpoint — resolution failures never reset page_token.

    If the list-suppliers API call itself fails (non-200/error response,
    after make_api_call's own retries are exhausted), _list_all_suppliers()
    raises CensysException and this method lets it propagate rather than
    falling back to "no supplier filter" — the caller (fetch_risk_events)
    aborts the run instead of proceeding with risk-events ingestion on an
    unknown/incomplete supplier set.

    Returns:
        List of resolved supplier UUIDs (empty only when
        CENSYS_SUPPLIER_NAMES is unset, or when every configured name was
        already resolved from cache with no API call needed).

    Raises:
        CensysException: If the list-suppliers API call fails, or if
            CENSYS_SUPPLIER_NAMES is set, the suppliers list was fetched
            successfully, and none of the configured names matched a
            supplier.
    """
    if not self.supplier_names:
      return []

    names_to_resolve = list(dict.fromkeys(
        n.strip() for n in self.supplier_names.split("|") if n.strip()
    ))
    if not names_to_resolve:
      return []

    # Load existing cache
    cache = self._load_supplier_cache()
    resolved_ids = []
    names_needing_resolution = []

    for name in names_to_resolve:
      if name in cache and cache[name].get("supplier_id"):
        resolved_ids.append(cache[name]["supplier_id"])
        utils.cloud_logging(
            f"Supplier '{name}' resolved from cache: "
            f"{cache[name]['supplier_id']}",
            severity="DEBUG",
        )
      else:
        names_needing_resolution.append(name)

    if not names_needing_resolution:
      utils.cloud_logging(
          f"All {len(resolved_ids)} supplier(s) resolved from cache."
      )
      return resolved_ids

    # Let CensysException propagate on failure (e.g. a non-200 response
    # from the list-suppliers endpoint) rather than catching it here — an
    # incomplete/unknown supplier catalog must abort the run, not silently
    # continue with only whatever was already cached.
    all_suppliers = self._list_all_suppliers()

    resolved_at = datetime.datetime.now(datetime.timezone.utc).isoformat()

    # Match each name against display_name
    for name in names_needing_resolution:
      matches = [
          s for s in all_suppliers if s.get("display_name") == name
      ]
      if len(matches) == 1:
        supplier_id = matches[0]["id"]
        cache[name] = {"supplier_id": supplier_id, "resolved_at": resolved_at}
        resolved_ids.append(supplier_id)
        utils.cloud_logging(
            f"Resolved supplier '{name}' -> {supplier_id}"
        )
      elif len(matches) == 0:
        utils.cloud_logging(
            f"Supplier name '{name}' did not match any supplier. "
            "Excluding from filter for this run.",
            severity="WARNING",
        )
      else:
        utils.cloud_logging(
            f"Supplier name '{name}' matched {len(matches)} suppliers. "
            "Excluding from filter (ambiguous match).",
            severity="WARNING",
        )

    # Persist updated cache (best-effort; failure does not affect event cursor)
    self._save_supplier_cache(cache)

    if names_to_resolve and not resolved_ids:
      raise exception_handler.CensysException(
          f"{constant.ENV_SUPPLIER_NAMES} contains {len(names_to_resolve)} "
          f"name(s) ({names_to_resolve}) and none resolved to a supplier "
          "ID. Aborting before risk-events ingestion — check for typos "
          "against the exact supplier display names in the Censys UI."
      )
    return resolved_ids

  def _load_risk_name_cache(self) -> dict[str, Any]:
    """Read the risk name cache from GCS.

    The cache maps risk display names to their resolved risk_type_ids.
    Returns an empty dict if the cache file does not exist.

    Returns:
        Dict of the form {'Risk Name': {'risk_type_id': '<id>',
        'resolved_at': '<iso_timestamp>'}, ...}.
    """
    try:
      storage_client = gcs_storage.Client()
      bucket = storage_client.get_bucket(self.bucket_name)
      blob = bucket.blob(constant.RISK_NAME_CACHE_FILE)
      if blob.exists():
        cache = json.loads(
            blob.download_as_text(timeout=constant.BLOB_DOWNLOAD_TIMEOUT)
        )
        utils.cloud_logging(
            f"Loaded risk name cache with {len(cache)} entries.",
            severity="DEBUG",
        )
        return cache
    except Exception as e:  # pylint: disable=broad-except
      utils.cloud_logging(
          f"Could not load risk name cache: {repr(e)}\n"
          f"Traceback: {traceback.format_exc()}",
          severity="WARNING",
      )
    return {}

  def _save_risk_name_cache(self, cache: dict[str, Any]) -> None:
    """Write the risk name cache to GCS.

    Args:
        cache: Resolved risk name cache dict to persist.
    """
    try:
      storage_client = gcs_storage.Client()
      bucket = storage_client.get_bucket(self.bucket_name)
      blob = bucket.blob(constant.RISK_NAME_CACHE_FILE)
      blob.upload_from_string(
          json.dumps(cache),
          content_type="application/json",
          timeout=30,
      )
      utils.cloud_logging(
          f"Saved risk name cache with {len(cache)} entries.",
          severity="DEBUG",
      )
    except Exception as e:  # pylint: disable=broad-except
      utils.cloud_logging(
          f"Could not save risk name cache: {repr(e)}\n"
          f"Traceback: {traceback.format_exc()}",
          severity="WARNING",
      )

  def _list_all_suppliers(self) -> list[dict[str, Any]]:
    """Fetch the full supplier list for the default supply chain, paginated.

    GET .../suppliers has no name/keyword search parameter, so every page
    must be read to find a match by display_name.

    Returns:
        The full list of supplier dicts across all pages.

    Raises:
        CensysException: If any page fetch fails.
    """
    suppliers_url = f"{self.base_url}{constant.SUPPLIERS_ENDPOINT}"
    all_suppliers: list[dict[str, Any]] = []
    page_token: Optional[str] = None

    while True:
      params: dict[str, Any] = {
          "organization_id": self.organization_id,
          "page_size": constant.MAX_SUPPLIERS_PAGE_SIZE,
      }
      if page_token:
        params["page_token"] = page_token

      response = self.make_api_call(
          "GET", suppliers_url, params=params, fetch_type="suppliers"
      )
      if not response.get("status"):
        raise exception_handler.CensysException(
            f"Error fetching suppliers: {response.get('error')}"
        )

      result = response.get("data", {}).get("result", {})
      all_suppliers.extend(result.get("suppliers", []))
      page_token = result.get("next_page_token", "")
      if not page_token:
        break

    return all_suppliers

  def _list_all_risks(self) -> list[dict[str, Any]]:
    """Fetch the full risk catalog for the default supply chain, paginated.

    GET .../risks has no name/keyword search parameter (unlike the
    suppliers endpoint), so every page must be read to find a match by
    name.

    Returns:
        The full list of risk dicts across all pages.

    Raises:
        CensysException: If any page fetch fails.
    """
    risks_url = f"{self.base_url}{constant.RISKS_ENDPOINT}"
    all_risks: list[dict[str, Any]] = []
    page_token: Optional[str] = None

    while True:
      params: dict[str, Any] = {
          "organization_id": self.organization_id,
          "page_size": constant.MAX_RISKS_PAGE_SIZE,
      }
      if page_token:
        params["page_token"] = page_token

      response = self.make_api_call(
          "GET", risks_url, params=params, fetch_type="risks"
      )
      if not response.get("status"):
        raise exception_handler.CensysException(
            f"Error fetching risks catalog: {response.get('error')}"
        )

      result = response.get("data", {}).get("result", {})
      all_risks.extend(result.get("risks", []))
      page_token = result.get("next_page_token", "")
      if not page_token:
        break

    return all_risks

  def _resolve_risk_type_ids(self) -> list[str]:
    """Resolve risk display names to risk_type_ids.

    Resolution logic (mirrors _resolve_supplier_ids):
    1. Call GET /v1/supplychains/default/risks, paginating through the
       full catalog via _list_all_risks() — this endpoint has no
       name/keyword search parameter, so every risk must be fetched to
       find a match.
    2. Match each configured name against risk.name.
    3. Names with zero or more-than-one match are skipped with a WARNING.
       If at least one configured name resolves, the run proceeds scoped
       to whatever did resolve. If every configured name fails to resolve
       (and the risk catalog was fetched successfully), a CensysException
       is raised instead of silently falling back to "no risk filter"
       (which would otherwise widen an intentionally scoped run to every
       risk type).

    Duplicate names in CENSYS_RISK_NAMES (e.g. "Risk A|Risk A") are
    deduplicated before resolution, so a repeated name contributes its
    resolved ID to the output only once.

    Cache: persisted to censys_risk_name_cache.json. A cache hit is used
    directly to avoid repeat API calls. The cache does NOT affect the event
    cursor checkpoint — resolution failures never reset page_token.

    If the list-risks API call itself fails (non-200/error response, after
    make_api_call's own retries are exhausted), _list_all_risks() raises
    CensysException and this method lets it propagate rather than falling
    back to "no risk filter" — the caller (fetch_risk_events) aborts the
    run instead of proceeding with risk-events ingestion on an
    unknown/incomplete risk catalog.

    Returns:
        List of resolved risk_type_id strings (empty only when
        CENSYS_RISK_NAMES is unset, or when every configured name was
        already resolved from cache with no API call needed).

    Raises:
        CensysException: If the list-risks API call fails, or if
            CENSYS_RISK_NAMES is set, the risk catalog was fetched
            successfully, and none of the configured names matched a risk.
    """
    if not self.risk_names:
      return []

    names_to_resolve = list(dict.fromkeys(
        n.strip() for n in self.risk_names.split("|") if n.strip()
    ))
    if not names_to_resolve:
      return []

    # Load existing cache
    cache = self._load_risk_name_cache()
    resolved_ids = []
    names_needing_resolution = []

    for name in names_to_resolve:
      if name in cache and cache[name].get("risk_type_id"):
        resolved_ids.append(cache[name]["risk_type_id"])
        utils.cloud_logging(
            f"Risk '{name}' resolved from cache: "
            f"{cache[name]['risk_type_id']}",
            severity="DEBUG",
        )
      else:
        names_needing_resolution.append(name)

    if not names_needing_resolution:
      utils.cloud_logging(
          f"All {len(resolved_ids)} risk name(s) resolved from cache."
      )
      return resolved_ids

    # Let CensysException propagate on failure (e.g. a non-200 response
    # from the list-risks endpoint) rather than catching it here — an
    # incomplete/unknown risk catalog must abort the run, not silently
    # continue with only whatever was already cached.
    all_risks = self._list_all_risks()

    resolved_at = datetime.datetime.now(datetime.timezone.utc).isoformat()

    # Match each name against risk.name
    for name in names_needing_resolution:
      matches = [r for r in all_risks if r.get("name") == name]
      if len(matches) == 1:
        risk_type_id = matches[0]["id"]
        cache[name] = {"risk_type_id": risk_type_id, "resolved_at": resolved_at}
        resolved_ids.append(risk_type_id)
        utils.cloud_logging(f"Resolved risk '{name}' -> {risk_type_id}")
      elif len(matches) == 0:
        utils.cloud_logging(
            f"Risk name '{name}' did not match any risk. "
            "Excluding from filter for this run.",
            severity="WARNING",
        )
      else:
        utils.cloud_logging(
            f"Risk name '{name}' matched {len(matches)} risks. "
            "Excluding from filter (ambiguous match).",
            severity="WARNING",
        )

    # Persist updated cache (best-effort; failure does not affect event cursor)
    self._save_risk_name_cache(cache)

    if names_to_resolve and not resolved_ids:
      raise exception_handler.CensysException(
          f"{constant.ENV_RISK_NAMES} contains {len(names_to_resolve)} "
          f"name(s) ({names_to_resolve}) and none resolved to a "
          "risk_type_id. Aborting before risk-events ingestion — check "
          "for typos against the exact risk names in the Censys risk "
          "catalog."
      )
    return resolved_ids

  def _ingest_events(self, events: list[dict[str, Any]]) -> None:
    """Ingest a list of risk events into Google Chronicle.

    Chunks events to MAX_BULK_INGEST_BATCH_SIZE and calls
    ingest_v1.ingest() for each chunk. Also checks the runtime budget
    before ingesting to raise RunTimeExceeded if needed.

    Args:
        events: List of risk event dicts to ingest.

    Raises:
        RunTimeExceeded: If the execution time budget is exceeded.
        Exception: If ingest_v1.ingest() raises for any other reason.
    """
    if not events:
      return

    # Check runtime budget before ingesting
    last_run_initiation_time = utility.get_last_checkpoint(
        self.bucket_name,
        constant.CHECKPOINT_KEY_LAST_RUN_INITIATION_TIME,
    )
    if last_run_initiation_time:
      try:
        last_run_time = float(last_run_initiation_time)
        current_time = time.time()
        time_diff_minutes = (current_time - last_run_time) / 60

        if time_diff_minutes >= constant.INGESTION_TIME_CHECK_MINUTES:
          utils.cloud_logging(
              "Execution time has exceeded "
              f"{constant.INGESTION_TIME_CHECK_MINUTES}"
              f" minutes (running for {time_diff_minutes:.2f} minutes). "
              "Raising RunTimeExceeded.",
              severity="WARNING",
          )
          raise exception_handler.RunTimeExceeded(
              "Execution time exceeded "
              f"{constant.INGESTION_TIME_CHECK_MINUTES} minutes"
          )
      except (ValueError, TypeError) as e:
        utils.cloud_logging(
            f"Error checking execution time: {repr(e)}. Continuing.\n"
            f"Traceback: {traceback.format_exc()}",
            severity="WARNING",
        )

    # Chunk events and ingest
    batch_size = constant.MAX_BULK_INGEST_BATCH_SIZE
    total_batches = (len(events) + batch_size - 1) // batch_size

    for batch_idx in range(total_batches):
      start = batch_idx * batch_size
      end = min(start + batch_size, len(events))
      batch = events[start:end]

      utils.cloud_logging(
          f"Ingesting batch {batch_idx + 1}/{total_batches} "
          f"({len(batch)} records) into Chronicle.",
      )
      ingest_v1.ingest(batch, constant.GOOGLE_SECOPS_DATA_TYPE)
      utils.cloud_logging(
          f"Ingested {len(batch)} records of type "
          f"{constant.GOOGLE_SECOPS_DATA_TYPE}.",
      )

  def fetch_risk_events(self) -> None:
    """Main entry point: paginate through risk-events and ingest each page.

    Flow:
    1. Resolve supplier IDs (if CENSYS_SUPPLIER_NAMES is configured) and
       risk_type_ids (if CENSYS_RISK_NAMES is configured).
    2. Read the persisted (inserted_after_time, inserted_after_event_id)
       watermark from the checkpoint. On first run (no checkpoint), seed
       inserted_after_time directly from CENSYS_INSERTED_AFTER_TIME
       (already validated as RFC3339 at startup; defaults to
       1970-01-01T00:00:00Z for full history).
    3. Build the run's filter params once (change_types, severity,
       rapid_response, inserted_after_time, inserted_after_event_id) —
       held constant across every page per the endpoint doc's pagination
       contract. supplier_ids/risk_type_ids are layered in per page
       alongside page_token.
    4. Loop: fetch one page, advance the watermark over every event
       returned, ingest, persist the watermark, repeat while
       next_page_token is non-empty.
    5. On HTTP 410 or any other terminal error: propagate — the watermark
       already reflects the last successfully ingested page, so the next
       run resumes correctly without any separate error-checkpoint step.

    This method is single-tenant; checkpoint keys are not prefixed.
    """
    utils.cloud_logging("Starting Censys risk events ingestion.")

    # Step 1a — supplier name resolution (conditional)
    supplier_ids: list[str] = []
    if self.supplier_names:
      utils.cloud_logging(
          f"Resolving supplier IDs for names: {self.supplier_names}"
      )
      try:
        supplier_ids = self._resolve_supplier_ids()
        utils.cloud_logging(
            f"Resolved {len(supplier_ids)} supplier ID(s): {supplier_ids}"
        )
      except exception_handler.CensysException:
        # All configured supplier names failed to resolve — a deliberate,
        # clean abort (see _resolve_supplier_ids), not a transient failure
        # to tolerate. Propagate rather than falling back to "no filter".
        raise
      except Exception as e:  # pylint: disable=broad-except
        utils.cloud_logging(
            "Supplier resolution failed; proceeding without filter: "
            f"{repr(e)}\n"
            f"Traceback: {traceback.format_exc()}",
            severity="WARNING",
        )
        supplier_ids = []

    # Step 1b — risk name resolution (conditional)
    risk_type_ids: list[str] = []
    if self.risk_names:
      utils.cloud_logging(
          f"Resolving risk type IDs for names: {self.risk_names}"
      )
      try:
        risk_type_ids = self._resolve_risk_type_ids()
        utils.cloud_logging(
            f"Resolved {len(risk_type_ids)} risk type ID(s): {risk_type_ids}"
        )
      except exception_handler.CensysException:
        # All configured risk names failed to resolve — a deliberate,
        # clean abort (see _resolve_risk_type_ids), not a transient
        # failure to tolerate. Propagate rather than falling back to "no
        # filter".
        raise
      except Exception as e:  # pylint: disable=broad-except
        utils.cloud_logging(
            "Risk name resolution failed; proceeding without filter: "
            f"{repr(e)}\n"
            f"Traceback: {traceback.format_exc()}",
            severity="WARNING",
        )
        risk_type_ids = []

    # Step 2 — load persisted watermark, or seed it from
    # CENSYS_INSERTED_AFTER_TIME
    watermark_time = utility.get_last_checkpoint(
        self.bucket_name,
        constant.CHECKPOINT_KEY_INSERTED_AFTER_TIME,
    )
    watermark_id = utility.get_last_checkpoint(
        self.bucket_name,
        constant.CHECKPOINT_KEY_INSERTED_AFTER_EVENT_ID,
    )

    if watermark_time:
      utils.cloud_logging(
          f"Resuming from checkpoint | inserted_after_time={watermark_time} "
          f"inserted_after_event_id={watermark_id or '(none)'}",
          severity="INFO",
      )
    else:
      watermark_time = self.inserted_after_time or constant.DEFAULT_VALUES.get(
          constant.ENV_INSERTED_AFTER_TIME
      )
      watermark_id = None
      utils.cloud_logging(
          "No checkpoint found. Seeding inserted_after_time from "
          f"CENSYS_INSERTED_AFTER_TIME: {watermark_time}",
          severity="INFO",
      )

    # Step 3 — build this run's constant filter params
    base_params = self._build_base_filter_params()
    base_params["inserted_after_time"] = watermark_time
    if watermark_id:
      base_params["inserted_after_event_id"] = watermark_id

    # Page size is not user-configurable — fixed at the documented default.
    page_size = constant.DEFAULT_PAGE_SIZE

    total_events_ingested = 0
    page_count = 0
    page_token: Optional[str] = None

    # Step 4 — pagination loop (page_token is in-run only; never persisted)
    while True:
      try:
        page_count += 1
        page_token_state = (
            "(present)" if page_token else "(none — first page)"
        )
        utils.cloud_logging(
            f"Fetching risk events page {page_count} "
            f"| page_token={page_token_state} "
            f"| page_size={page_size}",
        )

        result = self._get_risk_events_page(
            base_params=base_params,
            page_token=page_token,
            supplier_ids=supplier_ids,
            risk_type_ids=risk_type_ids,
            page_size=page_size,
        )

        risk_events = result.get("risk_events", [])
        next_page_token = result.get("next_page_token", "")

        next_page_token_state = "(present)" if next_page_token else "(empty)"
        utils.cloud_logging(
            f"Page {page_count} fetched {len(risk_events)} records "
            f"| next_page_token={next_page_token_state}",
        )

        # Advance the watermark over every event returned, then ingest.
        for event in risk_events:
          event_time = event.get("inserted_at")
          event_id = event.get("id")
          if self._is_later(event_time, event_id, watermark_time, watermark_id):
            watermark_time, watermark_id = event_time, event_id

        if risk_events:
          self._ingest_events(risk_events)
          total_events_ingested += len(risk_events)

        # Checkpoint AFTER successful ingest (write order: ingest → checkpoint)
        utility.set_last_checkpoint(
            self.bucket_name,
            constant.CHECKPOINT_KEY_INSERTED_AFTER_TIME,
            watermark_time,
        )
        if watermark_id:
          utility.set_last_checkpoint(
              self.bucket_name,
              constant.CHECKPOINT_KEY_INSERTED_AFTER_EVENT_ID,
              watermark_id,
          )
        utils.cloud_logging(
            f"Checkpoint updated after page {page_count} | "
            f"inserted_after_time={watermark_time} "
            f"inserted_after_event_id={watermark_id or '(none)'}",
            severity="DEBUG",
        )

        # Per the doc: "follow next_page_token until it is empty." There is
        # no end_of_events field on this endpoint.
        if not next_page_token:
          utils.cloud_logging(
              f"next_page_token empty on page {page_count}. "
              f"Total ingested this run: {total_events_ingested}. "
              "Exiting cleanly — scheduler will resume on next interval.",
              severity="INFO",
          )
          break

        page_token = next_page_token

      except exception_handler.RunTimeExceeded as e:
        utils.cloud_logging(
            f"RunTimeExceeded on page {page_count}. "
            f"Total ingested this run: {total_events_ingested}. "
            "Checkpoint already reflects the last successfully ingested "
            f"page.\nTraceback: {traceback.format_exc()}",
            severity="WARNING",
        )
        raise

      except exception_handler.CensysException as e:
        # Terminal error (401, 403, etc.) — checkpoint already reflects the
        # last successfully ingested page; nothing further to save.
        utils.cloud_logging(
            f"Terminal API error on page {page_count}: {repr(e)}\n"
            f"Traceback: {traceback.format_exc()}",
            severity="ERROR",
        )
        raise

      except Exception as e:  # pylint: disable=broad-except
        utils.cloud_logging(
            f"Unexpected exception on page {page_count}: {repr(e)}\n"
            f"Traceback: {traceback.format_exc()}",
            severity="ERROR",
        )
        raise

    utils.cloud_logging(
        f"Risk events ingestion complete. "
        f"Total pages: {page_count}. "
        f"Total events ingested: {total_events_ingested}.",
    )
