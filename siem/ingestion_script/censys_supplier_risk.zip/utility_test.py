# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# pylint: disable=line-too-long
# pylint: disable=g-importing-member
# pylint: disable=invalid-name
# pylint: disable=g-multiple-import
# pylint: disable=unused-argument
# pylint: disable=g-import-not-at-top
# pylint: disable=g-bad-import-order
# pylint: disable=missing-class-docstring
# pylint: disable=missing-function-docstring
# pylint: disable=g-bad-exception-name

"""Unit tests for the utility module."""

import json
import sys
import time
import unittest
from unittest.mock import MagicMock, patch

# --- Bootstrap mocks before any project imports ---

# Mock requests
mock_requests_mod = MagicMock()
sys.modules["requests"] = mock_requests_mod

# Mock google-cloud-storage
mock_storage_mod = MagicMock()
mock_exceptions_mod = MagicMock()


class MockNotFound(Exception):
  pass


class MockForbidden(Exception):
  pass


mock_exceptions_mod.NotFound = MockNotFound
mock_exceptions_mod.Forbidden = MockForbidden

mock_storage_mod.Client = MagicMock
mock_storage_mod.retry = MagicMock()
mock_storage_mod.retry.DEFAULT_RETRY = MagicMock()
mock_storage_mod.retry.DEFAULT_RETRY.with_delay.return_value = MagicMock()
mock_storage_mod.retry.DEFAULT_RETRY.with_delay.return_value.with_deadline.return_value = MagicMock()

sys.modules["google"] = MagicMock()
sys.modules["google.cloud"] = MagicMock()
sys.modules["google.cloud.storage"] = mock_storage_mod
sys.modules["google.cloud.exceptions"] = mock_exceptions_mod
sys.modules["google.cloud.resourcemanager_v3"] = MagicMock()

# Mock common modules
mock_utils_mod = MagicMock()
mock_env_constants_mod = MagicMock()
mock_env_constants_mod.ENV_CHRONICLE_SERVICE_ACCOUNT = "CHRONICLE_SERVICE_ACCOUNT"
mock_env_constants_mod.ENV_CHRONICLE_PROJECT_NUMBER = "CHRONICLE_PROJECT_NUMBER"

mock_common_mod = MagicMock()
mock_common_mod.utils = mock_utils_mod
mock_common_mod.env_constants = mock_env_constants_mod

sys.modules["common"] = mock_common_mod
sys.modules["common.utils"] = mock_utils_mod
sys.modules["common.env_constants"] = mock_env_constants_mod

# Patch google.cloud.exceptions inside utility
import google.cloud  # noqa: E402 (already mocked above)
google.cloud.exceptions = mock_exceptions_mod

from exception_handler import CensysException, GCPPermissionDeniedError, GCSBucketNotFoundError  # noqa: E402
import constant  # noqa: E402
import utility  # noqa: E402

# Wire the mocked exception classes into utility's namespace
utility.exceptions = mock_exceptions_mod
utility.GCPPermissionDeniedError = GCPPermissionDeniedError
utility.CensysException = CensysException
utility.GCSBucketNotFoundError = GCSBucketNotFoundError

INGESTION_SCRIPTS_PATH = ""


class TestGetEnvironmentVariable(unittest.TestCase):
  """Tests for get_environment_variable."""

  @patch(f"{INGESTION_SCRIPTS_PATH}utility.utils.get_env_var", return_value="myval")
  def test_plain_env_var(self, mock_get_env):
    result = utility.get_environment_variable("SOME_VAR")
    self.assertEqual(result, "myval")

  @patch(f"{INGESTION_SCRIPTS_PATH}utility.utils.get_value_from_secret_manager", return_value="secret!")
  @patch.dict("os.environ", {"MY_SECRET": "projects/x/secrets/y/versions/1"})
  def test_secret_env_var_with_version(self, mock_sm):
    result = utility.get_environment_variable("MY_SECRET", is_secret=True)
    self.assertEqual(result, "secret!")
    mock_sm.assert_called_once_with("projects/x/secrets/y/versions/1")

  @patch(f"{INGESTION_SCRIPTS_PATH}utility.utils.get_value_from_secret_manager", return_value="secret2")
  @patch.dict("os.environ", {"MY_SECRET": "projects/x/secrets/y"})
  def test_secret_env_var_appends_version_latest(self, mock_sm):
    result = utility.get_environment_variable("MY_SECRET", is_secret=True)
    self.assertEqual(result, "secret2")
    mock_sm.assert_called_once_with("projects/x/secrets/y/versions/latest")

  @patch(
      f"{INGESTION_SCRIPTS_PATH}utility.utils.get_value_from_secret_manager",
      return_value="  secret-with-stray-whitespace\n",
  )
  @patch.dict("os.environ", {"MY_SECRET": "projects/x/secrets/y/versions/1"})
  def test_secret_env_var_is_trimmed(self, mock_sm):
    result = utility.get_environment_variable("MY_SECRET", is_secret=True)
    self.assertEqual(result, "secret-with-stray-whitespace")

  def test_required_secret_missing_raises(self):
    with patch.dict("os.environ", {}, clear=True):
      with self.assertRaises(RuntimeError):
        utility.get_environment_variable(
            "MISSING_SECRET", is_required=True, is_secret=True
        )

  @patch(f"{INGESTION_SCRIPTS_PATH}utility.utils.get_env_var", return_value=None)
  def test_optional_missing_returns_empty_string(self, mock_get_env):
    result = utility.get_environment_variable("OPTIONAL_VAR")
    self.assertEqual(result, "")

  @patch.dict("os.environ", {"  CENSYS_INSERTED_AFTER_TIME  ": "2020-01-01T00:00:00Z"}, clear=True)
  @patch(f"{INGESTION_SCRIPTS_PATH}utility.utils.get_env_var", return_value="2020-01-01T00:00:00Z")
  def test_plain_env_var_tolerates_whitespace_padded_key(self, mock_get_env):
    # A manual env var edit (e.g. via the GCP Console UI) can leave stray
    # whitespace around the variable NAME itself, not just its value. The
    # padded key actually present in os.environ — not the clean name — must
    # be what gets looked up.
    result = utility.get_environment_variable("CENSYS_INSERTED_AFTER_TIME")
    self.assertEqual(result, "2020-01-01T00:00:00Z")
    mock_get_env.assert_called_once_with(
        "  CENSYS_INSERTED_AFTER_TIME  ",
        required=False,
        is_secret=False,
        default="1970-01-01T00:00:00Z",
    )

  @patch(f"{INGESTION_SCRIPTS_PATH}utility.utils.get_value_from_secret_manager", return_value="secret!")
  @patch.dict("os.environ", {"  MY_SECRET  ": "projects/x/secrets/y/versions/1"}, clear=True)
  def test_secret_env_var_tolerates_whitespace_padded_key(self, mock_sm):
    result = utility.get_environment_variable("MY_SECRET", is_secret=True)
    self.assertEqual(result, "secret!")
    mock_sm.assert_called_once_with("projects/x/secrets/y/versions/1")

  @patch.dict("os.environ", {"CENSYS_INSERTED_AFTER_TIME": "exact-match-value", "  CENSYS_INSERTED_AFTER_TIME  ": "padded-key-value"}, clear=True)
  @patch(f"{INGESTION_SCRIPTS_PATH}utility.utils.get_env_var", return_value="exact-match-value")
  def test_exact_key_match_preferred_over_whitespace_padded_key(self, mock_get_env):
    # When both an exact and a whitespace-padded key happen to exist, the
    # exact match must win.
    result = utility.get_environment_variable("CENSYS_INSERTED_AFTER_TIME")
    self.assertEqual(result, "exact-match-value")
    mock_get_env.assert_called_once_with(
        "CENSYS_INSERTED_AFTER_TIME",
        required=False,
        is_secret=False,
        default="1970-01-01T00:00:00Z",
    )


class TestParseBooleanEnv(unittest.TestCase):
  """Tests for parse_boolean_env."""

  def test_true_string(self):
    self.assertTrue(utility.parse_boolean_env("true"))

  def test_true_mixed_case(self):
    self.assertTrue(utility.parse_boolean_env("TRUE"))

  def test_false_string(self):
    self.assertFalse(utility.parse_boolean_env("false"))

  def test_empty_string(self):
    self.assertFalse(utility.parse_boolean_env(""))

  def test_none_value(self):
    self.assertFalse(utility.parse_boolean_env(None))


class TestValidateIntegerEnv(unittest.TestCase):
  """Tests for validate_integer_env."""

  def test_valid_integer_string(self):
    result = utility.validate_integer_env("7", "DAYS")
    self.assertEqual(result, 7)

  def test_valid_integer(self):
    result = utility.validate_integer_env(10, "DAYS")
    self.assertEqual(result, 10)

  def test_none_with_default(self):
    result = utility.validate_integer_env(None, "DAYS", default_value="14")
    self.assertEqual(result, 14)

  def test_none_without_default(self):
    result = utility.validate_integer_env(None, "DAYS")
    self.assertIsNone(result)

  def test_invalid_string_raises(self):
    with self.assertRaises(CensysException):
      utility.validate_integer_env("abc", "DAYS")

  def test_negative_raises(self):
    with self.assertRaises(CensysException):
      utility.validate_integer_env(-1, "DAYS")

  def test_zero_raises(self):
    with self.assertRaises(CensysException):
      utility.validate_integer_env(0, "DAYS")


class TestValidateRfc3339Env(unittest.TestCase):
  """Tests for validate_rfc3339_env."""

  def test_valid_z_suffixed_timestamp(self):
    result = utility.validate_rfc3339_env("1970-01-01T00:00:00Z", "TS")
    self.assertEqual(result, "1970-01-01T00:00:00Z")

  def test_valid_offset_suffixed_timestamp(self):
    result = utility.validate_rfc3339_env("2026-10-22T00:00:00+05:30", "TS")
    self.assertEqual(result, "2026-10-22T00:00:00+05:30")

  def test_valid_with_fractional_seconds(self):
    result = utility.validate_rfc3339_env("2026-10-22T00:00:00.123456Z", "TS")
    self.assertEqual(result, "2026-10-22T00:00:00.123456Z")

  def test_none_with_default(self):
    result = utility.validate_rfc3339_env(
        None, "TS", default_value="1970-01-01T00:00:00Z"
    )
    self.assertEqual(result, "1970-01-01T00:00:00Z")

  def test_empty_string_with_default(self):
    result = utility.validate_rfc3339_env(
        "", "TS", default_value="1970-01-01T00:00:00Z"
    )
    self.assertEqual(result, "1970-01-01T00:00:00Z")

  def test_none_without_default(self):
    result = utility.validate_rfc3339_env(None, "TS")
    self.assertIsNone(result)

  def test_missing_timezone_raises(self):
    with self.assertRaises(CensysException):
      utility.validate_rfc3339_env("1970-01-01T00:00:00", "TS")

  def test_malformed_date_raises(self):
    with self.assertRaises(CensysException):
      utility.validate_rfc3339_env("not-a-date Z", "TS")

  def test_invalid_calendar_date_raises(self):
    with self.assertRaises(CensysException):
      utility.validate_rfc3339_env("2026-13-45T00:00:00Z", "TS")


class TestGetTenantCheckpointKey(unittest.TestCase):
  """Tests for get_tenant_checkpoint_key."""

  def test_basic_key(self):
    result = utility.get_tenant_checkpoint_key("mytenant", "my_key")
    self.assertEqual(result, "mytenant_my_key")

  def test_sanitises_special_chars(self):
    result = utility.get_tenant_checkpoint_key("my.tenant@co", "key")
    self.assertNotIn(".", result)
    self.assertNotIn("@", result)
    self.assertTrue(result.endswith("_key"))


class TestGetLastCheckpoint(unittest.TestCase):
  """Tests for get_last_checkpoint."""

  def _make_storage_client(self, blob_exists=True, blob_content=None):
    storage_client = MagicMock()
    bucket = MagicMock()
    blob = MagicMock()
    blob.exists.return_value = blob_exists
    if blob_content is not None:
      blob.download_as_text.return_value = json.dumps(blob_content)
    bucket.blob.return_value = blob
    storage_client.get_bucket.return_value = bucket
    return storage_client, blob

  @patch("utility.storage.Client")
  def test_returns_value_when_key_exists(self, mock_client_cls):
    sc, _ = self._make_storage_client(
        blob_exists=True,
        blob_content={"risk_events_next_page_token": "abc123"},
    )
    mock_client_cls.return_value = sc

    result = utility.get_last_checkpoint("my-bucket", "risk_events_next_page_token")
    self.assertEqual(result, "abc123")

  @patch("utility.storage.Client")
  def test_returns_none_when_key_absent(self, mock_client_cls):
    sc, _ = self._make_storage_client(
        blob_exists=True, blob_content={"other_key": "val"}
    )
    mock_client_cls.return_value = sc

    result = utility.get_last_checkpoint("my-bucket", "missing_key")
    self.assertIsNone(result)

  @patch("utility.storage.Client")
  def test_returns_none_when_file_not_exists(self, mock_client_cls):
    sc, _ = self._make_storage_client(blob_exists=False)
    mock_client_cls.return_value = sc

    result = utility.get_last_checkpoint("my-bucket", "some_key")
    self.assertIsNone(result)

  @patch("utility.storage.Client")
  def test_returns_none_on_json_decode_error(self, mock_client_cls):
    storage_client = MagicMock()
    bucket = MagicMock()
    blob = MagicMock()
    blob.exists.return_value = True
    blob.download_as_text.return_value = "not-json{"
    bucket.blob.return_value = blob
    storage_client.get_bucket.return_value = bucket
    mock_client_cls.return_value = storage_client

    result = utility.get_last_checkpoint("my-bucket", "key")
    self.assertIsNone(result)

  @patch("utility.storage.Client")
  def test_raises_bucket_not_found_error_on_bucket_not_found(self, mock_client_cls):
    storage_client = MagicMock()
    storage_client.get_bucket.side_effect = MockNotFound("bucket not found")
    mock_client_cls.return_value = storage_client

    # GCSBucketNotFoundError subclasses RuntimeError, so this also verifies
    # backward compatibility with any existing `except RuntimeError` callers.
    with self.assertRaises(GCSBucketNotFoundError) as ctx:
      utility.get_last_checkpoint("bad-bucket", "key")
    self.assertIn("bad-bucket", str(ctx.exception))

  @patch("utility.storage.Client")
  def test_raises_gcp_permission_denied_on_forbidden(self, mock_client_cls):
    storage_client = MagicMock()
    storage_client.get_bucket.side_effect = MockForbidden("forbidden")
    mock_client_cls.return_value = storage_client

    with self.assertRaises(GCPPermissionDeniedError):
      utility.get_last_checkpoint("my-bucket", "key")


class TestSetLastCheckpoint(unittest.TestCase):
  """Tests for set_last_checkpoint."""

  def _make_storage_client(self, blob_exists=True, existing_data=None):
    storage_client = MagicMock()
    bucket = MagicMock()
    blob = MagicMock()
    blob.exists.return_value = blob_exists
    if existing_data is not None:
      blob.download_as_text.return_value = json.dumps(existing_data)
    else:
      blob.download_as_text.return_value = json.dumps({})
    bucket.blob.return_value = blob
    storage_client.get_bucket.return_value = bucket
    return storage_client, blob

  @patch("utility.storage.Client")
  @patch("utility.storage.retry")
  def test_writes_new_checkpoint(self, mock_retry, mock_client_cls):
    mock_retry.DEFAULT_RETRY.with_delay.return_value.with_deadline.return_value = MagicMock()
    sc, blob = self._make_storage_client(blob_exists=False)
    mock_client_cls.return_value = sc

    utility.set_last_checkpoint("my-bucket", "my_key", "my_value")

    blob.upload_from_string.assert_called_once()
    uploaded = json.loads(blob.upload_from_string.call_args[0][0])
    self.assertEqual(uploaded["my_key"], "my_value")

  @patch("utility.storage.Client")
  @patch("utility.storage.retry")
  def test_merges_existing_checkpoint(self, mock_retry, mock_client_cls):
    mock_retry.DEFAULT_RETRY.with_delay.return_value.with_deadline.return_value = MagicMock()
    sc, blob = self._make_storage_client(
        blob_exists=True, existing_data={"old_key": "old_value"}
    )
    mock_client_cls.return_value = sc

    utility.set_last_checkpoint("my-bucket", "new_key", "new_value")

    uploaded = json.loads(blob.upload_from_string.call_args[0][0])
    self.assertEqual(uploaded["old_key"], "old_value")
    self.assertEqual(uploaded["new_key"], "new_value")

  @patch("utility.storage.Client")
  def test_raises_gcp_permission_denied_on_forbidden(self, mock_client_cls):
    storage_client = MagicMock()
    storage_client.get_bucket.side_effect = MockForbidden("forbidden")
    mock_client_cls.return_value = storage_client

    with self.assertRaises(GCPPermissionDeniedError):
      utility.set_last_checkpoint("my-bucket", "key", "val")

  @patch("utility.storage.Client")
  def test_raises_bucket_not_found_error_on_bucket_not_found(self, mock_client_cls):
    storage_client = MagicMock()
    storage_client.get_bucket.side_effect = MockNotFound("not found")
    mock_client_cls.return_value = storage_client

    with self.assertRaises(GCSBucketNotFoundError) as ctx:
      utility.set_last_checkpoint("my-bucket", "key", "val")
    self.assertIn("my-bucket", str(ctx.exception))


class TestClearCheckpointIfExists(unittest.TestCase):
  """Tests for clear_checkpoint_if_exists."""

  @patch("utility.set_last_checkpoint")
  @patch("utility.get_last_checkpoint", return_value="existing_value")
  def test_clears_existing_checkpoint(self, mock_get, mock_set):
    utility.clear_checkpoint_if_exists("my-bucket", "some_key")
    mock_set.assert_called_once_with("my-bucket", "some_key", None, constant.CHECKPOINT_FILE)

  @patch("utility.set_last_checkpoint")
  @patch("utility.get_last_checkpoint", return_value=None)
  def test_skips_when_value_is_none(self, mock_get, mock_set):
    utility.clear_checkpoint_if_exists("my-bucket", "some_key")
    mock_set.assert_not_called()


class TestAcquireProcessLock(unittest.TestCase):
  """Tests for acquire_process_lock."""

  @patch("utility.set_last_checkpoint")
  @patch("utility.get_last_checkpoint", return_value=None)
  def test_acquires_fresh_lock(self, mock_get, mock_set):
    result = utility.acquire_process_lock("my-bucket")
    self.assertTrue(result)
    self.assertEqual(mock_set.call_count, 2)

  @patch("utility.set_last_checkpoint")
  @patch("utility.get_last_checkpoint")
  def test_returns_false_when_lock_is_held(self, mock_get, mock_set):
    mock_get.side_effect = ["true", str(time.time())]  # lock=true, recent initiation time
    result = utility.acquire_process_lock("my-bucket")
    self.assertFalse(result)

  @patch("utility.set_last_checkpoint")
  @patch("utility.get_last_checkpoint")
  def test_recovers_stale_lock(self, mock_get, mock_set):
    # Lock is "true" but run was started 60 minutes ago (> MAX_EXECUTION_TIME_MINUTES)
    stale_time = str(time.time() - 60 * 60)
    mock_get.side_effect = ["true", stale_time]
    result = utility.acquire_process_lock("my-bucket")
    self.assertTrue(result)

  @patch("utility.set_last_checkpoint")
  @patch("utility.get_last_checkpoint")
  def test_returns_false_when_no_initiation_time(self, mock_get, mock_set):
    mock_get.side_effect = ["true", None]
    result = utility.acquire_process_lock("my-bucket")
    self.assertFalse(result)

  @patch("utility.set_last_checkpoint")
  @patch("utility.get_last_checkpoint")
  def test_returns_false_on_invalid_initiation_time(self, mock_get, mock_set):
    mock_get.side_effect = ["true", "not-a-number"]
    result = utility.acquire_process_lock("my-bucket")
    self.assertFalse(result)


class TestReleaseProcessLock(unittest.TestCase):
  """Tests for release_process_lock."""

  @patch("utility.set_last_checkpoint")
  def test_sets_lock_to_false(self, mock_set):
    utility.release_process_lock("my-bucket")
    mock_set.assert_called_once_with(
        "my-bucket",
        constant.CHECKPOINT_KEY_PROCESS_LOCK,
        "false",
    )

  @patch(
      "utility.set_last_checkpoint",
      side_effect=RuntimeError("GCS error"),
  )
  def test_logs_error_but_does_not_raise(self, mock_set):
    # release_process_lock should not propagate exceptions
    try:
      utility.release_process_lock("my-bucket")
    except Exception as e:  # pylint: disable=broad-except
      self.fail(f"release_process_lock raised unexpectedly: {e}")


class TestCheckSufficientPermissions(unittest.TestCase):
  """Tests for check_sufficient_permissions_on_service_account."""

  @patch("utility.utils.get_env_var", return_value='{"type":"service_account"}')
  def test_skips_check_with_static_sa(self, mock_get_env):
    result = utility.check_sufficient_permissions_on_service_account()
    self.assertTrue(result)

  @patch("utility.requests.get")
  @patch("utility.get_environment_variable", return_value="12345")
  @patch("utility.google.cloud.resourcemanager_v3.ProjectsClient")
  @patch("utility.utils.get_env_var", return_value=None)
  def test_passes_when_owner_role_present(
      self, mock_get_env, mock_client_cls, mock_get_project, mock_requests_get
  ):
    mock_requests_get.return_value.text = "test-sa@project.iam.gserviceaccount.com"
    mock_client = MagicMock()
    mock_client_cls.return_value = mock_client

    binding = MagicMock()
    binding.role = "roles/owner"
    binding.members = ["serviceAccount:test-sa@project.iam.gserviceaccount.com"]
    mock_client.get_iam_policy.return_value.bindings = [binding]

    result = utility.check_sufficient_permissions_on_service_account()
    self.assertTrue(result)

  @patch("utility.requests.get")
  @patch("utility.get_environment_variable", return_value="12345")
  @patch("utility.google.cloud.resourcemanager_v3.ProjectsClient")
  @patch("utility.utils.get_env_var", return_value=None)
  def test_raises_when_permissions_missing(
      self, mock_get_env, mock_client_cls, mock_get_project, mock_requests_get
  ):
    mock_requests_get.return_value.text = "sa@project.iam.gserviceaccount.com"
    mock_client = MagicMock()
    mock_client_cls.return_value = mock_client
    # No bindings at all — all roles missing
    mock_client.get_iam_policy.return_value.bindings = []

    with self.assertRaises(GCPPermissionDeniedError):
      utility.check_sufficient_permissions_on_service_account()


if __name__ == "__main__":
  unittest.main()
