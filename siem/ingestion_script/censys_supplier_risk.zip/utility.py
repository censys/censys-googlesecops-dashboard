# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# pylint: disable=g-docstring-first-line-too-long

"""Utility functions for Censys Supplier Risk ingestion scripts."""

import datetime
import json
import os
import re
import time
import traceback
from typing import Any, Optional, Union

from common import env_constants
from common import utils
import constant
from exception_handler import CensysException
from exception_handler import GCPPermissionDeniedError
from exception_handler import GCSBucketNotFoundError
from google.cloud import exceptions
from google.cloud import storage
import google.cloud.resourcemanager_v3
import requests


# Timeout constants (in seconds)
METADATA_REQUEST_TIMEOUT = 5


def _resolve_env_var_key(name: str) -> str:
  """Resolve the actual os.environ key for ``name``, tolerating whitespace.

  Manually editing env vars after deployment (e.g. via the GCP Console UI,
  or a hand-typed `gcloud ... --set-env-vars`) can leave stray leading/
  trailing whitespace around the variable NAME itself, e.g.
  "  CENSYS_INSERTED_AFTER_TIME  " instead of "CENSYS_INSERTED_AFTER_TIME".
  os.environ is looked up by exact key match, so such a key would
  otherwise never be found under its intended name. This checks for an
  exact match first, then falls back to a whitespace-trimmed match.

  Args:
      name: The expected (clean) environment variable name.

  Returns:
      The key as actually present in os.environ, or ``name`` unchanged if
      neither an exact nor a trimmed match is found.
  """
  if name in os.environ:
    return name
  for actual_key in os.environ:
    if actual_key.strip() == name:
      return actual_key
  return name


def get_environment_variable(
    name: str, *, is_required: bool = False, is_secret: bool = False
) -> str:
  """Retrieve environment variable value.

  For secret variables, the env var holds the Secret Manager resource path,
  and the actual value is fetched from Secret Manager.

  Tolerates stray whitespace around the variable's NAME in os.environ (see
  _resolve_env_var_key) in addition to trimming the returned value itself.

  Args:
      name: Name of the environment variable.
      is_required: If True, raises RuntimeError when the variable is absent.
      is_secret: If True, reads the value from Google Cloud Secret Manager.

  Returns:
      The resolved environment variable value (or empty string if optional
      and absent).

  Raises:
      RuntimeError: If is_required=True and the variable is not set.
  """
  resolved_name = _resolve_env_var_key(name)
  default_value = constant.DEFAULT_VALUES.get(name, "")
  if is_secret:
    if resolved_name not in os.environ and is_required:
      raise RuntimeError(f"Environment variable {name} is required.")
    secret_path = os.environ[resolved_name]
    if "versions" not in secret_path:
      secret_path = secret_path + "/versions/latest"
    return utils.get_value_from_secret_manager(secret_path).strip()
  env_value = utils.get_env_var(
      resolved_name,
      required=is_required,
      is_secret=is_secret,
      default=default_value,
  )
  if env_value is None:
    return ""
  return str(env_value).strip()


def parse_boolean_env(value: str) -> bool:
  """Parse string to boolean.

  Args:
      value: String value to parse (e.g. "true", "false").

  Returns:
      True if value is "true" (case-insensitive), False otherwise.
  """
  return value.lower() == "true" if value else False


def validate_integer_env(
    value: Union[int, str, None],
    param_name: str,
    default_value: Optional[str] = None,
) -> Optional[int]:
  """Validate if the given value is a positive integer.

  Args:
      value: The value to be validated.
      param_name: The name of the parameter for error messages.
      default_value: The default value to use if ``value`` is None.

  Returns:
      The validated integer value, or None if ``value`` is None and no
      ``default_value`` is provided.

  Raises:
      CensysException: If the value is not a valid positive integer.
  """
  is_empty = value is None
  if is_empty:
    return (
        None
        if not default_value
        else validate_integer_env(default_value, param_name, None)
    )

  try:
    int_value = value if isinstance(value, int) else int(value)
  except (ValueError, TypeError, AttributeError) as exc:
    utils.cloud_logging(
        f"Error validating {param_name}: {repr(exc)}\n"
        f"Traceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    raise CensysException(f"{param_name} must be an integer.") from exc

  if int_value < 0:
    raise CensysException(f"{param_name} must be a non-negative integer.")
  if int_value == 0:
    raise CensysException(f"{param_name} must be greater than zero.")

  return int_value


_RFC3339_TZ_SUFFIX_RE = re.compile(r"(Z|z|[+-]\d{2}:\d{2})$")


def validate_rfc3339_env(
    value: Optional[str],
    param_name: str,
    default_value: Optional[str] = None,
) -> Optional[str]:
  """Validate that the given value is an RFC3339 timestamp.

  Requires an explicit timezone designator ('Z' or a '+HH:MM'/'-HH:MM'
  offset), matching the strict interpretation the Censys API expects for
  inserted_after_time — a naive, timezone-less datetime is rejected rather
  than silently assumed to be UTC.

  Args:
      value: The value to be validated.
      param_name: The name of the parameter for error messages.
      default_value: The default value to use if ``value`` is empty.

  Returns:
      The validated timestamp string (unmodified, not reformatted), or None
      if ``value`` is empty and no ``default_value`` is provided.

  Raises:
      CensysException: If the value is not a valid RFC3339 timestamp.
  """
  is_empty = value is None or not str(value).strip()
  if is_empty:
    return (
        None
        if not default_value
        else validate_rfc3339_env(default_value, param_name, None)
    )

  v = str(value).strip()
  if not _RFC3339_TZ_SUFFIX_RE.search(v):
    raise CensysException(
        f"{param_name} must be an RFC3339 timestamp with an explicit 'Z' or "
        f"timezone offset, e.g. 1970-01-01T00:00:00Z. Got: '{value}'."
    )

  candidate = v[:-1] + "+00:00" if v.endswith(("Z", "z")) else v
  try:
    datetime.datetime.fromisoformat(candidate)
  except ValueError as exc:
    utils.cloud_logging(
        f"Error validating {param_name}: {repr(exc)}\n"
        f"Traceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    raise CensysException(
        f"{param_name} must be a valid RFC3339 timestamp, e.g. "
        f"1970-01-01T00:00:00Z. Got: '{value}'."
    ) from exc

  return v


def get_tenant_checkpoint_key(tenant_name: str, checkpoint_key: str) -> str:
  """Generate tenant-specific checkpoint key.

  Note: Censys SR is a single-tenant product. This helper exists for
  structural symmetry with the reference plugin but is NOT called in the
  Censys client — checkpoint keys are used without a tenant prefix.

  Args:
      tenant_name: The tenant name.
      checkpoint_key: The base checkpoint key.

  Returns:
      Tenant-prefixed checkpoint key (e.g. 'tenant_a_my_key').
  """
  safe_tenant_name = re.sub(r"[^a-zA-Z0-9_-]", "_", tenant_name)
  return f"{safe_tenant_name}_{checkpoint_key}"


def get_last_checkpoint(
    bucket_name: str,
    checkpoint_key: str,
    checkpoint_file: str = constant.CHECKPOINT_FILE,
) -> Optional[str]:
  """Retrieve the last checkpoint value for a given key from GCS.

  Reads the JSON blob from the GCS bucket and returns the value stored
  under ``checkpoint_key``, or None if the file/key does not exist.

  Args:
      bucket_name: The name of the GCS bucket.
      checkpoint_key: The key to retrieve from the checkpoint JSON.
      checkpoint_file: The checkpoint blob filename in the bucket.

  Returns:
      The checkpoint value as a string, or None if absent.

  Raises:
      GCPPermissionDeniedError: If the service account lacks bucket access.
      GCSBucketNotFoundError: If the bucket does not exist.
  """
  try:
    storage_client = storage.Client()
    bucket = storage_client.get_bucket(bucket_name)
    blob = bucket.blob(checkpoint_file)

    if blob.exists():
      data = json.loads(
          blob.download_as_text(timeout=constant.BLOB_DOWNLOAD_TIMEOUT)
      )
      value = data.get(checkpoint_key, None)
      utils.cloud_logging(
          f"Retrieved checkpoint key '{checkpoint_key}' from "
          f"'{checkpoint_file}' | value={value}",
          severity="DEBUG",
      )
      return value
    else:
      utils.cloud_logging(
          f"Checkpoint file '{checkpoint_file}' in bucket "
          f"'{bucket_name}' does not exist.",
          severity="DEBUG",
      )
      return None

  except json.JSONDecodeError:
    utils.cloud_logging(
        f"Failed to decode JSON content from '{checkpoint_file}'\n"
        f"Traceback: {traceback.format_exc()}",
        severity="WARNING",
    )
    return None

  except exceptions.NotFound as error:
    utils.cloud_logging(
        f"Bucket not found: {bucket_name}\n"
        f"Traceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    raise GCSBucketNotFoundError(bucket_name) from error

  except exceptions.Forbidden as e:
    error_msg = (
        f"Permission denied while accessing GCS bucket '{bucket_name}'."
    )
    utils.cloud_logging(
        f"{error_msg} Error: {e}\nTraceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    raise GCPPermissionDeniedError(
        message=error_msg,
        resource=f"gs://{bucket_name}/{checkpoint_file}",
        permissions=["Storage Admin"],
    ) from e

  except Exception as e:  # pylint: disable=broad-except
    utils.cloud_logging(
        "Unknown exception occurred while getting last checkpoint. "
        f"Error message: {e}\nTraceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    return None


def set_last_checkpoint(
    bucket_name: str,
    checkpoint_key: str,
    value: Any,
    checkpoint_file: str = constant.CHECKPOINT_FILE,
) -> None:
  """Store a checkpoint value for the given key in GCS.

  Reads any existing JSON blob, merges the new key-value pair, and
  writes it back atomically.

  Args:
      bucket_name: The name of the GCS bucket.
      checkpoint_key: The key to set in the checkpoint JSON.
      value: The value to store.
      checkpoint_file: The checkpoint blob filename in the bucket.

  Raises:
      GCPPermissionDeniedError: If the service account lacks bucket access.
      GCSBucketNotFoundError: If the bucket does not exist.
  """
  try:
    custom_retry = storage.retry.DEFAULT_RETRY.with_delay(
        initial=1.0, maximum=30.0, multiplier=1.5
    ).with_deadline(120.0)
    storage_client = storage.Client()
    bucket = storage_client.get_bucket(bucket_name)
    blob = bucket.blob(checkpoint_file)

    bucket_data = {}
    if blob.exists():
      try:
        bucket_data = json.loads(
            blob.download_as_text(timeout=constant.BLOB_DOWNLOAD_TIMEOUT)
        )
        utils.cloud_logging(
            f"Read existing checkpoint data from '{checkpoint_file}'",
            severity="DEBUG",
        )
      except json.JSONDecodeError:
        utils.cloud_logging(
            f"Failed to decode JSON from '{checkpoint_file}'\n"
            f"Traceback: {traceback.format_exc()}",
            severity="WARNING",
        )
    else:
      utils.cloud_logging(
          f"Checkpoint file '{checkpoint_file}' does not exist, creating new.",
          severity="DEBUG",
      )

    bucket_data[checkpoint_key] = value
    blob.upload_from_string(
        json.dumps(bucket_data),
        content_type="application/json",
        retry=custom_retry,
        timeout=30,
    )
    utils.cloud_logging(
        f"Updated checkpoint file '{checkpoint_file}' | "
        f"key='{checkpoint_key}' value={value}",
        severity="DEBUG",
    )

  except exceptions.Forbidden as e:
    error_msg = (
        f"Permission denied while accessing GCS bucket '{bucket_name}'."
    )
    utils.cloud_logging(
        f"{error_msg} Error: {repr(e)}\nTraceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    raise GCPPermissionDeniedError(
        message=error_msg,
        resource=f"gs://{bucket_name}/{checkpoint_file}",
        permissions=["Storage Admin"],
    ) from e

  except exceptions.NotFound as e:
    error_msg = f"The specified bucket '{bucket_name}' does not exist."
    utils.cloud_logging(
        f"{error_msg}\nTraceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    raise GCSBucketNotFoundError(bucket_name) from e

  except Exception as e:
    utils.cloud_logging(
        f"Error updating checkpoint '{checkpoint_key}' in "
        f"'{checkpoint_file}': {repr(e)}\n"
        f"Traceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    raise


def clear_checkpoint_if_exists(
    bucket_name: str,
    checkpoint_key: str,
    checkpoint_file: str = constant.CHECKPOINT_FILE,
) -> None:
  """Clear a checkpoint key by setting it to None if it currently exists.

  Args:
      bucket_name: The name of the GCS bucket.
      checkpoint_key: The key to clear.
      checkpoint_file: The checkpoint blob filename in the bucket.
  """
  existing_value = get_last_checkpoint(
      bucket_name, checkpoint_key, checkpoint_file
  )
  if existing_value is not None:
    set_last_checkpoint(bucket_name, checkpoint_key, None, checkpoint_file)
    utils.cloud_logging(
        f"Cleared checkpoint key '{checkpoint_key}' in '{checkpoint_file}'."
    )


def acquire_process_lock(bucket_name: str) -> bool:
  """Attempt to acquire the process lock to prevent overlapping executions.

  Reads the current lock state from the checkpoint file. If another process
  is running, returns False. If the lock is stale (last-run age >=
  MAX_EXECUTION_TIME_MINUTES), it self-recovers by resetting the lock.

  Args:
      bucket_name: The name of the GCS bucket.

  Returns:
      True if the lock was acquired, False if another process is already
      running.

  Raises:
      Exception: If unable to read or set the lock due to GCS errors.
  """
  try:
    existing_lock = get_last_checkpoint(
        bucket_name, constant.CHECKPOINT_KEY_PROCESS_LOCK
    )
    current_time = time.time()

    if existing_lock == "true":
      last_run_initiation_time = get_last_checkpoint(
          bucket_name,
          constant.CHECKPOINT_KEY_LAST_RUN_INITIATION_TIME,
      )

      if last_run_initiation_time:
        try:
          last_run_time = float(last_run_initiation_time)
          time_diff_minutes = (current_time - last_run_time) / 60

          if time_diff_minutes >= constant.MAX_EXECUTION_TIME_MINUTES:
            utils.cloud_logging(
                "Lock is running but last run time was "
                f"{time_diff_minutes:.2f} minutes ago, which exceeds "
                f"the limit of {constant.MAX_EXECUTION_TIME_MINUTES} minutes."
                " Resetting lock.",
                severity="WARNING",
            )
            set_last_checkpoint(
                bucket_name,
                constant.CHECKPOINT_KEY_PROCESS_LOCK,
                "true",
            )
            set_last_checkpoint(
                bucket_name,
                constant.CHECKPOINT_KEY_LAST_RUN_INITIATION_TIME,
                current_time,
            )
            utils.cloud_logging(
                "Process lock acquired successfully after stale-lock reset.",
                severity="INFO",
            )
            return True
          else:
            utils.cloud_logging(
                "Another process is already running "
                f"(started {time_diff_minutes:.2f} minutes ago). "
                "Lock status: true. Skipping execution to prevent "
                "overlapping runs.",
                severity="WARNING",
            )
            return False
        except (ValueError, TypeError) as e:
          utils.cloud_logging(
              "Invalid last_run_initiation_time value: "
              f"{last_run_initiation_time}. Error: {repr(e)}. "
              "Treating as if lock is stuck.\n"
              f"Traceback: {traceback.format_exc()}",
              severity="WARNING",
          )
          return False
      else:
        utils.cloud_logging(
            "Another process is already running. Lock status: true. "
            "Skipping execution to prevent overlapping runs.",
            severity="WARNING",
        )
        return False

    set_last_checkpoint(
        bucket_name,
        constant.CHECKPOINT_KEY_PROCESS_LOCK,
        "true",
    )
    set_last_checkpoint(
        bucket_name,
        constant.CHECKPOINT_KEY_LAST_RUN_INITIATION_TIME,
        current_time,
    )
    utils.cloud_logging(
        "Process lock acquired successfully. Setting lock status to true "
        f"and last_run_initiation_time to {current_time}.",
        severity="INFO",
    )
    return True

  except Exception as e:
    utils.cloud_logging(
        f"Failed to acquire process lock: {repr(e)}\n"
        f"Traceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    raise


def release_process_lock(bucket_name: str) -> None:
  """Release the process lock to allow future executions.

  Args:
      bucket_name: The name of the GCS bucket.
  """
  try:
    set_last_checkpoint(
        bucket_name,
        constant.CHECKPOINT_KEY_PROCESS_LOCK,
        "false",
    )
    utils.cloud_logging(
        "Process lock released successfully. Setting lock status to false.",
        severity="INFO",
    )
  except Exception as e:  # pylint: disable=broad-except
    utils.cloud_logging(
        f"Failed to release process lock: {repr(e)}. "
        "This may prevent future executions until manually cleared.\n"
        f"Traceback: {traceback.format_exc()}",
        severity="ERROR",
    )


def check_sufficient_permissions_on_service_account() -> bool:
  """Check if the service account has sufficient permissions.

  If a static Chronicle service account key is provided via env var,
  the check is skipped (the key itself carries the necessary privileges).
  Otherwise, it fetches the IAM policy for the Chronicle project and
  verifies that the compute default service account has all required roles.

  Returns:
      True if the service account has sufficient permissions.

  Raises:
      GCPPermissionDeniedError: If required IAM roles are missing.
      RuntimeError: For unexpected errors during the permission check.
  """
  missing_permissions = set()
  service_account = utils.get_env_var(
      env_constants.ENV_CHRONICLE_SERVICE_ACCOUNT, required=False
  )
  if not service_account:  # If static service account key is not provided
    try:
      client = google.cloud.resourcemanager_v3.ProjectsClient()
      chronicle_project_number = get_environment_variable(
          env_constants.ENV_CHRONICLE_PROJECT_NUMBER
      )
      resource_name = f"projects/{chronicle_project_number}"
      policy = client.get_iam_policy(request={"resource": resource_name})
      service_account_email = requests.get(
          "http://metadata.google.internal/computeMetadata/v1/"
          "instance/service-accounts/default/email",
          headers={"Metadata-Flavor": "Google"},
          timeout=(constant.CONNECTION_TIMEOUT, constant.READ_TIMEOUT),
      ).text
    except Exception as e:
      utils.cloud_logging(
          f"Unexpected error: {repr(e)}\nTraceback: {traceback.format_exc()}"
      )
      raise RuntimeError(
          "An unexpected error occurred during service account permission check"
      ) from e

    service_account_member = f"serviceAccount:{service_account_email}"
    is_owner = any(
        service_account_member in binding.members
        for binding in policy.bindings
        if binding.role == "roles/owner"
    )
    if is_owner:
      utils.cloud_logging(
          "Service account has roles/owner, "
          "which includes all necessary permissions."
      )
      return True
    for permission_name, role in constant.PERMISSION_DETAILS.items():
      if not any(
          service_account_member in binding.members
          for binding in policy.bindings
          if binding.role == role
      ):
        missing_permissions.add(permission_name)

    if missing_permissions:
      error_msg = (
          f"Service account - {service_account_email} does not have "
          "sufficient permissions."
      )
      utils.cloud_logging(
          f"Service account - {service_account_email} does not have "
          "sufficient permissions.",
          severity="ERROR",
      )
      raise GCPPermissionDeniedError(
          message=error_msg,
          resource=resource_name,
          permissions=list(missing_permissions),
      )
    else:
      utils.cloud_logging("Service account has sufficient permissions.")
      return True
  else:
    utils.cloud_logging(
        "Permission check skipped as static service account key is provided."
    )
    return True
