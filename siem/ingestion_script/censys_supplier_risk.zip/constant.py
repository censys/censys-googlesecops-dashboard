# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Censys Supplier Risk Constants for Google SecOps SIEM Integration."""

import immutabledict

# Single source of truth for this connector's release version. Used both
# as the product version and as the GoogleSecopsSIEM version in the
# User-Agent template below (see CensysClient._build_auth_headers()) — kept
# as one constant since the connector and its GoogleSecopsSIEM packaging
# are versioned together today.
INTEGRATION_VERSION = "1.0.0"

# Rebuilt on every API call (not a static string) so ts= reflects the time
# of that specific request. {python_version} and {epoch_time} are filled in
# at call time by platform.python_version() and int(time.time()).
USER_AGENT_TEMPLATE = (
    "CensysSRGoogleSecopsSIEM/{version} (GoogleSecopsSIEM/{version}; "
    "Python/{python_version}; ts={epoch_time})"
)

# ENVIRONMENT VARIABLE CONSTANTS
ENV_API_KEY = "CENSYS_API_KEY"
ENV_ORGANIZATION_ID = "CENSYS_ORGANIZATION_ID"
ENV_SUPPLIER_NAMES = "CENSYS_SUPPLIER_NAMES"
# First-run seed for the inserted_after_time watermark (see Checkpoint
# Details in censys_client.fetch_risk_events). Default of
# 1970-01-01T00:00:00Z matches the endpoint doc's own suggestion for "full
# history".
ENV_INSERTED_AFTER_TIME = "CENSYS_INSERTED_AFTER_TIME"
ENV_GCP_BUCKET_NAME = "GCP_BUCKET_NAME"

# Risk-events filter inputs, per
# https://docs.censys.com/reference/v1-supply-chain-list-risk-events
ENV_SEVERITY = "CENSYS_SEVERITY"
ENV_CHANGE_TYPES = "CENSYS_CHANGE_TYPES"
# Pipe-separated ('|') risk display names (e.g. "Exposed SMTP Service"),
# resolved to risk_type_ids via the list-risks endpoint — see
# CensysClient._resolve_risk_type_ids(). Pipe, not comma, is the delimiter
# here (and for CENSYS_SUPPLIER_NAMES/CENSYS_SEVERITY/CENSYS_CHANGE_TYPES
# below) because a comma inside an env var's value breaks manual
# deployment via `gcloud ... --set-env-vars`, which itself uses comma to
# separate different KEY=VALUE pairs.
ENV_RISK_NAMES = "CENSYS_RISK_NAMES"
ENV_RAPID_RESPONSE = "CENSYS_RAPID_RESPONSE"

# Allowed values for the enum-constrained filters above (per the endpoint
# doc). CensysClient._validate_enum_filter() rejects anything outside these
# sets with a CensysException rather than passing bad input to the API or
# silently dropping it. Casing here matches what the client normalizes each
# filter to before validating (severity upper, change_types/rapid_response
# lower) — see CensysClient._build_base_filter_params().
ALLOWED_SEVERITY_VALUES = frozenset({"LOW", "MEDIUM", "HIGH", "CRITICAL"})
ALLOWED_CHANGE_TYPES = frozenset({"opened", "resolved", "reopened"})
ALLOWED_RAPID_RESPONSE_VALUES = frozenset({"true", "false"})

# Descriptions for each CENSYS_* input, quoted/adapted from the endpoint doc.
ENV_PARAM_DESCRIPTIONS = immutabledict.immutabledict({
    ENV_ORGANIZATION_ID: (
        "The ID of a Censys organization to associate the request with."
    ),
    ENV_API_KEY: (
        "Censys Personal Access Token (PAT). Sent as 'Authorization: Bearer "
        "<token>' on every request. Stored as a Secret Manager reference, "
        "not a plain env var."
    ),
    ENV_INSERTED_AFTER_TIME: (
        "RFC3339 timestamp (e.g. 1970-01-01T00:00:00Z) used to seed the "
        "initial inserted_after_time watermark on the very first run (no "
        "prior checkpoint). Per the endpoint doc's own guidance: start from "
        "the time the sync begins, or 1970-01-01T00:00:00Z for full "
        "history. Default: 1970-01-01T00:00:00Z (full history). Must "
        "include an explicit 'Z' or timezone offset."
    ),
    ENV_SEVERITY: (
        "Filter to one or more severities. For multiple values, use "
        "pipe-separated ('|') values, e.g. HIGH|CRITICAL (pipe, not "
        "comma, since a comma inside the value breaks manual deployment "
        "via `gcloud ... --set-env-vars`). Connectors are expected to "
        "default to HIGH|CRITICAL for alerting use cases. Accepted "
        "values: LOW, MEDIUM, HIGH, CRITICAL."
    ),
    ENV_CHANGE_TYPES: (
        "Filter to one or more change types. For multiple values, use "
        "pipe-separated ('|') values, e.g. opened|resolved|reopened. "
        "Accepted values: opened, resolved, reopened."
    ),
    ENV_SUPPLIER_NAMES: (
        "Pipe-separated ('|') supplier display names, e.g. 'Supplier "
        "A|Supplier B'. Each name is resolved to a supplier UUID via the "
        "suppliers endpoint (GET /v1/supplychains/default/suppliers) and "
        "the resolved IDs are sent as the supplier_ids filter. If every "
        "configured name fails to resolve, the run aborts with a "
        "CensysException rather than silently including every supplier; "
        "if at least one resolves, the run proceeds scoped to the ones "
        "that did (invalid names are logged as a WARNING). Omit to "
        "include every supplier in the supply chain (per the doc: 'When "
        "omitted, every supplier in the supply chain is included' — "
        "unless it has more than 1000 suppliers, in which case this must "
        "be set)."
    ),
    ENV_RAPID_RESPONSE: (
        "Filter to risk events flagged (or not flagged) for rapid "
        "response. Omit to include both. Accepted values: true, false."
    ),
    ENV_RISK_NAMES: (
        "Pipe-separated ('|') risk display names (e.g. 'Exposed SMTP "
        "Service|Weak TLS Cipher'). Each name is resolved to a "
        "risk_type_id via the list-risks endpoint (GET "
        "/v1/supplychains/default/risks) and the resolved IDs are sent as "
        "the risk_type_ids filter. If every configured name fails to "
        "resolve, the run aborts with a CensysException rather than "
        "silently including every risk type; if at least one resolves, "
        "the run proceeds scoped to the ones that did (invalid names are "
        "logged as a WARNING). Omit to include every risk type."
    ),
})

# Default values for optional environment variables
DEFAULT_VALUES = immutabledict.immutabledict(
    {
        ENV_INSERTED_AFTER_TIME: "1970-01-01T00:00:00Z",
    }
)

# Censys Platform API base URL. Not user-configurable — hardcoded rather
# than read from an environment variable.
CENSYS_API_BASE_URL = "https://api.platform.censys.io"

# API Endpoints. The supply_chain_id path segment is hardcoded to the
# literal "default" — there is no env var (or any other way) for an
# operator to supply a different one, so there's nothing to substitute at
# call time. Per the endpoint doc: "If set to 'default', will list risk
# events for the organization's primary supply chain." This resolves
# server-side, so no separate list-supply-chains call is needed either.
RISK_EVENTS_ENDPOINT = "/v1/supplychains/default/risk-events"
# Per https://docs.censys.com/reference/v1-supply-chain-list-suppliers — has
# no name/keyword search parameter, so resolving CENSYS_SUPPLIER_NAMES
# requires paginating through the full supplier list. page_size max is 100
# here (distinct from risk-events' max of 1000).
SUPPLIERS_ENDPOINT = "/v1/supplychains/default/suppliers"
MAX_SUPPLIERS_PAGE_SIZE = 100
# Per https://docs.censys.com/reference/v1-supply-chain-list-risks — has no
# name/keyword search parameter, so resolving CENSYS_RISK_NAMES requires
# paginating through the full catalog. page_size max is 100 here (distinct
# from risk-events' max of 1000).
RISKS_ENDPOINT = "/v1/supplychains/default/risks"
MAX_RISKS_PAGE_SIZE = 100

# Timeouts (in seconds)
CONNECTION_TIMEOUT = 60
READ_TIMEOUT = 300
DEFAULT_SLEEP_TIME = 60
BLOB_DOWNLOAD_TIMEOUT = 30
MAX_EXECUTION_TIME_MINUTES = 55
INGESTION_TIME_CHECK_MINUTES = 50

# Retry configuration
RETRY_COUNT = 3

# Pagination defaults
DEFAULT_PAGE_SIZE = 1000
MAX_PAGE_SIZE = 1000

# Maximum events to ingest in a single Chronicle batch
MAX_BULK_INGEST_BATCH_SIZE = 1000

# Chronicle SecOps data type for ingestion
GOOGLE_SECOPS_DATA_TYPE = "CENSYS_SUPPLIER_RISK_CUSTOM"

# Checkpoint configuration — single-tenant: keys are NOT prefixed
CHECKPOINT_FILE = "censys_checkpoint.json"
SUPPLIER_CACHE_FILE = "censys_supplier_name_cache.json"
RISK_NAME_CACHE_FILE = "censys_risk_name_cache.json"
# Cross-run checkpoint, per the endpoint doc's documented polling strategy:
# "For the next poll, pass the inserted_at and id of the last event
# processed as inserted_after_time and inserted_after_event_id." page_token
# is NOT persisted across runs — it is only a within-run pagination cursor,
# always sent alongside the same inserted_after_time/inserted_after_event_id
# that originally returned it.
CHECKPOINT_KEY_INSERTED_AFTER_TIME = "risk_events_inserted_after_time"
CHECKPOINT_KEY_INSERTED_AFTER_EVENT_ID = "risk_events_inserted_after_event_id"
CHECKPOINT_KEY_PROCESS_LOCK = "process_running"
CHECKPOINT_KEY_LAST_RUN_INITIATION_TIME = "last_run_initiation_time"
CHECKPOINT_KEY_SUPPLIER_NAME_CACHE = "supplier_name_cache"

# Message constants used in logging
GENERAL_ERROR_MESSAGE = (
    "Failed to fetch {fetch_type}, received status code - {status_code}."
    " Response - {response_text}."
)
CHECK_LOGS_FOR_MORE_DETAILS = " Check logs for more details."
RETRY_MESSAGE = "Retrying after {delay} seconds."

# Maximum Retry-After header value to honour (seconds)
MAX_RETRY_AFTER_SECONDS = 300

PERMISSION_DETAILS = immutabledict.immutabledict(
    {
        "Storage Admin": "roles/storage.admin",
        "Secret Manager Secret Accessor": "roles/secretmanager.secretAccessor",
        "Cloud Scheduler Job Runner": "roles/cloudscheduler.jobRunner",
        "Chronicle API Editor": "roles/chronicle.editor",
    }
)
