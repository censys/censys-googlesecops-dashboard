# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Main script for Censys Supplier Risk to Google SecOps SIEM ingestion."""

import traceback

import censys_client
from common import utils
import constant
import exception_handler
import utility


def main(request):  # pylint: disable=unused-argument
  """Driver function for Censys Supplier Risk data ingestion.

  This function:
  1. Checks GCP IAM permissions for the service account.
  2. Loads and validates required environment variables.
  3. Acquires a GCS-backed process lock to prevent overlapping executions.
  4. Initializes the CensysClient and fetches risk events via cursor pagination.
  5. Releases the process lock on completion or error.

  This is a single-tenant connector: no tenant name env var is needed and
  checkpoint keys are never prefixed.

  Args:
      request: The HTTP request object from Cloud Functions (unused).

  Returns:
      A tuple of (message: str, status_code: int) where message describes
      the outcome and status_code is the HTTP status code:
        - 200: success or soft runtime-exceeded exit (scheduler should not
          retry)
        - 400: product API error, or GCS bucket misconfiguration
          (GCP_BUCKET_NAME does not point to an existing bucket)
        - 403: GCP IAM permission denied
        - 409: another execution is already running
        - 500: unexpected initialization error
  """
  bucket_name = None

  try:
    utility.check_sufficient_permissions_on_service_account()

    utils.cloud_logging("Starting Censys Supplier Risk ingestion process.")

    bucket_name = utility.get_environment_variable(
        constant.ENV_GCP_BUCKET_NAME, is_required=True
    )

    if not utility.acquire_process_lock(bucket_name):
      return (
          "Another process is already running. Skipping execution.",
          409,
      )

    access_token = utility.get_environment_variable(
        constant.ENV_API_KEY, is_required=True, is_secret=True
    )
    organization_id = utility.get_environment_variable(
        constant.ENV_ORGANIZATION_ID, is_required=True
    )
    supplier_names = utility.get_environment_variable(
        constant.ENV_SUPPLIER_NAMES
    )
    risk_names = utility.get_environment_variable(
        constant.ENV_RISK_NAMES
    )
    inserted_after_time_str = utility.get_environment_variable(
        constant.ENV_INSERTED_AFTER_TIME
    )
    inserted_after_time = utility.validate_rfc3339_env(
        inserted_after_time_str,
        constant.ENV_INSERTED_AFTER_TIME,
        default_value=constant.DEFAULT_VALUES.get(
            constant.ENV_INSERTED_AFTER_TIME
        ),
    )

    utils.cloud_logging(
        f"Configuration loaded | organization_id={organization_id} "
        f"supplier_names={'(set)' if supplier_names else '(none)'} "
        f"risk_names={'(set)' if risk_names else '(none)'} "
        f"inserted_after_time={inserted_after_time}"
    )

    client = censys_client.CensysClient(
        access_token=access_token,
        organization_id=organization_id,
        supplier_names=supplier_names,
        risk_names=risk_names,
        inserted_after_time=inserted_after_time,
        bucket_name=bucket_name,
    )

    ingestion_result = None
    try:
      client.fetch_risk_events()
      ingestion_result = ("Data ingestion completed successfully.", 200)

    except exception_handler.RunTimeExceeded as e:
      utils.cloud_logging(
          "Execution time limit exceeded during Censys risk events ingestion. "
          f"Error message: {str(e)}\nTraceback: {traceback.format_exc()}",
          severity="WARNING",
      )
      ingestion_result = (f"Execution time limit exceeded: {repr(e)}", 200)

    except exception_handler.CensysException as e:
      utils.cloud_logging(
          "Error occurred during Censys risk events ingestion. "
          f"Error message: {str(e)}\nTraceback: {traceback.format_exc()}",
          severity="ERROR",
      )
      ingestion_result = (f"Error during Censys data ingestion: {repr(e)}", 400)

    except Exception as e:  # pylint: disable=broad-except
      utils.cloud_logging(
          "Unknown exception occurred during Censys risk events ingestion. "
          f"Error message: {str(e)}\nTraceback: {traceback.format_exc()}",
          severity="ERROR",
      )
      ingestion_result = (
          f"An unknown error occurred during Censys data ingestion: {repr(e)}",
          500,
      )

    finally:
      try:
        utility.release_process_lock(bucket_name)
      except Exception as lock_err:  # pylint: disable=broad-except
        utils.cloud_logging(
            f"Failed to release process lock: {repr(lock_err)}\n"
            f"Traceback: {traceback.format_exc()}",
            severity="ERROR",
        )

    return ingestion_result

  except exception_handler.GCPPermissionDeniedError as e:
    utils.cloud_logging(
        "The service account does not have sufficient permissions for Censys "
        f"ingestion. Error message: {str(e)}\n"
        f"Traceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    if bucket_name:
      utility.release_process_lock(bucket_name)
    return (
        (
            "The service account does not have sufficient permissions "
            "for Censys Supplier Risk ingestion."
        ),
        403,
    )

  except exception_handler.GCSBucketNotFoundError as e:
    utils.cloud_logging(
        f"GCS bucket configuration error: {str(e)}\n"
        f"Traceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    if bucket_name:
      utility.release_process_lock(bucket_name)
    return (
        f"GCS bucket not found: {str(e)}. Check the GCP_BUCKET_NAME "
        "environment variable.",
        400,
    )

  except Exception as e:  # pylint: disable=broad-except
    utils.cloud_logging(
        f"Unknown exception occurred during initialization: {repr(e)}\n"
        f"Traceback: {traceback.format_exc()}",
        severity="ERROR",
    )
    if bucket_name:
      utility.release_process_lock(bucket_name)
    return f"Error initializing: {repr(e)}", 500
